#include "Surface.h"
#include "viewport.h"
#include <glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <cmath>
enum XYZ { X = 0, Y, Z };

#define COPY_PT(DST, SRC)               do { (DST)[X] = SRC[X]; (DST)[Y] = SRC[Y]; } while (0)
#define VECTOR3_X_SCALA_ADD(O, V, S)    do { O[X] += (S) * (V)[X]; O[Y] += (S) * (V)[Y]; O[Z] += (S) * (V)[Z]; } while (0)

#ifdef DEBUG
void PRINT_CTRLPTS(CubicBezierSurface* crv) {
	int i;
	printf("Surface %p\n[\n", crv);
	for (i=0; i<4; ++i)
		printf("[%f, %f]\n", crv->control_pts[i][X], crv->control_pts[i][Y]);
	printf("]\n");
}
#endif

void evaluate(const BicubicBezierSurface *Surface, const double t1, const double t2, Point value)
{
	const double t1_inv = 1.0f - t1;
	const double t1_inv_sq = t1_inv * t1_inv;
	const double t1_sq = t1 * t1;
	const double t2_inv = 1.0f - t2;
	const double t2_inv_sq = t2_inv * t2_inv;
	const double t2_sq = t2 * t2;

	double b[2][4];
	b[0][0] = t1_inv_sq * t1_inv;
	b[0][1] = 3 * t1_inv_sq * t1;
	b[0][2] = 3 * t1_inv * t1_sq;
	b[0][3] = t1_sq * t1;
	b[1][0] = t2_inv_sq * t2_inv;
	b[1][1] = 3 * t2_inv_sq * t2;
	b[1][2] = 3 * t2_inv * t2_sq;
	b[1][3] = t2_sq * t2;

	SET_PT3(value, 0, 0, 0);
	for (int i = 0; i < 4; i++)
	for (int j = 0; j < 4; j++)
		VECTOR3_X_SCALA_ADD(value, Surface->control_pts[i][j], b[0][i] * b[1][j]);
}

void evaluateMesh(const double surface[RES + 1][RES + 1][3],
	double r,
	std::vector<std::vector<Vector3d>> &uPartialDerivative,
	std::vector<std::vector<Vector3d>> &vPartialDerivative,
	std::vector<std::vector<Vector3d>> &mesh)
{

	for (int i = 0; i < RES; i++) {
		for (int j = 0; j < RES; j++) {
			uPartialDerivative[i][j].x = surface[i][j + 1][0] - surface[i][j][0];
			uPartialDerivative[i][j].y = surface[i][j + 1][1] - surface[i][j][1];
			uPartialDerivative[i][j].z = surface[i][j + 1][2] - surface[i][j][2];

			vPartialDerivative[i][j].x = surface[i + 1][j][0] - surface[i][j][0];
			vPartialDerivative[i][j].y = surface[i + 1][j][1] - surface[i][j][1];
			vPartialDerivative[i][j].z = surface[i + 1][j][2] - surface[i][j][2];
		}
	}

	Vector3d n;
	for (int i = 0; i < RES; i++) {
		for (int j = 0; j < RES; j++) {
			Vector3d uDev(uPartialDerivative[i][j].x, uPartialDerivative[i][j].y, uPartialDerivative[i][j].z);
			Vector3d vDev(vPartialDerivative[i][j].x, vPartialDerivative[i][j].y, vPartialDerivative[i][j].z);
			
			n.cross(uDev, vDev);
			n.normalize();

			mesh[i][j].x = surface[i][j][0] + r * n.x;
			mesh[i][j].y = surface[i][j][1] + r * n.y;
			mesh[i][j].z = surface[i][j][2] + r * n.z;

			if (j == RES-1) {
				mesh[i][RES].x = surface[i][RES][0] + r * n.x;
				mesh[i][RES].y = surface[i][RES][1] + r * n.y;
				mesh[i][RES].z = surface[i][RES][2] + r * n.z;
			}
		}
		if (i == RES - 1) {
			for (int ind = 0; ind <= RES; ind++) {
				mesh[RES][ind].x = surface[RES][ind][0] + r * n.x;
				mesh[RES][ind].y = surface[RES][ind][1] + r * n.y;
				mesh[RES][ind].z = surface[RES][ind][2] + r * n.z;
			}
		}
	}
}

double calculationEPS(std::vector<std::vector<Vector3d>> &pointsMesh, Vector3d lu, Vector3d ru, Vector3d rd, Vector3d ld, int columnStart, int rowStart, int heightNextGap) {
	double eps;
	double maxEPS = DBL_MIN;
	Vector3d biLinearSurf;
	double u, v;

	for (int i = 0; i < heightNextGap; i++) {
		u = (double)i / (double)heightNextGap;
		for (int j = 0; j < heightNextGap; j++) {
			v = (double)j / (double)heightNextGap;
			biLinearSurf.x = (1 - u)*(1 - v)*lu.x + u * (1 - v)* ld.x + (1 - u)* v * ru.x + u * v*rd.x;
			biLinearSurf.y = (1 - u)*(1 - v)*lu.y + u * (1 - v)* ld.y + (1 - u)* v * ru.y + u * v*rd.y;
			biLinearSurf.z = (1 - u)*(1 - v)*lu.z + u * (1 - v)* ld.z + (1 - u)* v * ru.z + u * v*rd.z;
			eps = powf(pointsMesh[columnStart + i][rowStart + j].x - biLinearSurf.x, 2)
				+ powf(pointsMesh[columnStart + i][rowStart + j].y - biLinearSurf.y, 2)
				+ powf(pointsMesh[columnStart + i][rowStart + j].z - biLinearSurf.z, 2);
			
			if (eps > maxEPS) {
				maxEPS = eps;
			}
		}
	}

	return maxEPS;
}

void makingTree(std::vector<std::vector<Vector3d>> &pointsMesh, DividedPlane *planeArr) {
	int heightCount = 4;
	int height = 1;
	int heightNextGap = pow(2, 10 - height);
	int	nextStart = heightCount / 4 + 1;
	int planeInd = 0;
	int rowStart, columnStart;
	double calEPS;
	
	for (int i = 0; i < nextStart; i++) {
		columnStart = i * heightNextGap;
		for (int j = 0; j < nextStart; j++) {
			rowStart = j * heightNextGap;
			planeArr[planeInd].child1 = (planeInd + 1) * 4;
			planeArr[planeInd].child2 = (planeInd + 1) * 4 + 1;
			planeArr[planeInd].child3 = (planeInd + 1) * 4 + 2;
			planeArr[planeInd].child4 = (planeInd + 1) * 4 + 3;
			planeArr[planeInd].parent = -1;
			planeArr[planeInd].lu.set(pointsMesh[columnStart][rowStart].x, 
										pointsMesh[columnStart][rowStart].y,
										pointsMesh[columnStart][rowStart].z);
	

			planeArr[planeInd].ru.set(pointsMesh[columnStart][rowStart+heightNextGap].x,
										pointsMesh[columnStart][rowStart + heightNextGap].y,
										pointsMesh[columnStart][rowStart + heightNextGap].z);


			planeArr[planeInd].rd.set(pointsMesh[columnStart + heightNextGap][rowStart + heightNextGap].x,
										pointsMesh[columnStart + heightNextGap][rowStart + heightNextGap].y,
										pointsMesh[columnStart + heightNextGap][rowStart + heightNextGap].z);
			

			planeArr[planeInd].ld.set(pointsMesh[columnStart + heightNextGap][rowStart].x,
										pointsMesh[columnStart + heightNextGap][rowStart].y,
										pointsMesh[columnStart + heightNextGap][rowStart].z);
			
			planeArr[planeInd].cr[0] = columnStart;
			planeArr[planeInd].cr[1] = rowStart;
			planeArr[planeInd].nextGap = heightNextGap;

			calEPS = calculationEPS(pointsMesh, planeArr[planeInd].lu, 
												planeArr[planeInd].ru, 
												planeArr[planeInd].rd, 
												planeArr[planeInd].ld, 
												columnStart, rowStart, heightNextGap);

			planeArr[planeInd].eps = calEPS;

			planeInd++;
		}
	}

	/*for (int i = 0; i < planeInd; i++) {
		printf("planeind = %d\n", i);
		printf("lux = %f, luy = %f, luz = %f\n", planeArr[i].lu.x, planeArr[i].lu.y, planeArr[i].lu.z);
		printf("rux = %f, ruy = %f, ruz = %f\n", planeArr[i].ru.x, planeArr[i].ru.y, planeArr[i].ru.z);
		printf("rdx = %f, rdy = %f, rdz = %f\n", planeArr[i].rd.x, planeArr[i].rd.y, planeArr[i].rd.z);
		printf("ldx = %f, ldy = %f, ldz = %f\n", planeArr[i].ld.x, planeArr[i].ld.y, planeArr[i].ld.z);
	}*/

	heightNextGap /= 2;
	height++;
	heightCount *= 4;
	nextStart *= 2;

	do {
		for (int i = 0; i < nextStart; i++) {
			columnStart = i * heightNextGap;
			for (int j = 0; j < nextStart; j++) {
				rowStart = j * heightNextGap;
				if (heightNextGap != 1) {
					planeArr[planeInd].child1 = (planeInd + 1) * 4;
					planeArr[planeInd].child2 = (planeInd + 1) * 4 + 1;
					planeArr[planeInd].child3 = (planeInd + 1) * 4 + 2;
					planeArr[planeInd].child4 = (planeInd + 1) * 4 + 3;
				}
				else {
					planeArr[planeInd].child1 = -1;
					planeArr[planeInd].child2 =	-1;
					planeArr[planeInd].child3 =	-1;
					planeArr[planeInd].child4 = -1;
				}

				planeArr[planeInd].parent = planeInd / 4 - 1;
				planeArr[planeInd].lu.set(pointsMesh[columnStart][rowStart].x,
											pointsMesh[columnStart][rowStart].y,
											pointsMesh[columnStart][rowStart].z);
				planeArr[planeInd].ru.set(pointsMesh[columnStart][rowStart + heightNextGap].x,
											pointsMesh[columnStart][rowStart + heightNextGap].y,
											pointsMesh[columnStart][rowStart + heightNextGap].z);
				planeArr[planeInd].rd.set(pointsMesh[columnStart + heightNextGap][rowStart + heightNextGap].x,
											pointsMesh[columnStart + heightNextGap][rowStart + heightNextGap].y,
											pointsMesh[columnStart + heightNextGap][rowStart + heightNextGap].z);
				planeArr[planeInd].ld.set(pointsMesh[columnStart + heightNextGap][rowStart].x,
											pointsMesh[columnStart + heightNextGap][rowStart].y,
											pointsMesh[columnStart + heightNextGap][rowStart].z);
				
				planeArr[planeInd].cr[0] = columnStart;
				planeArr[planeInd].cr[1] = rowStart;
				planeArr[planeInd].nextGap = heightNextGap;

				calEPS = calculationEPS(pointsMesh, planeArr[planeInd].lu, planeArr[planeInd].ru, planeArr[planeInd].rd, planeArr[planeInd].ld, columnStart, rowStart, heightNextGap);

				planeArr[planeInd].eps = calEPS;

				planeInd++;
			}
		}
		heightNextGap /= 2;
		height++;
		heightCount *= 4;
		nextStart *= 2;
	} while (heightNextGap > 0);
}
void drawLine(std::vector<std::vector<Vector3d>> &pointsMesh, DividedPlane plane) {

	int length = plane.nextGap;

	glColor3f(0, 0, 0);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= length; i++)
	{
		glVertex3f(pointsMesh[plane.cr[0]][plane.cr[1] + i].x, pointsMesh[plane.cr[0]][plane.cr[1] + i].y, pointsMesh[plane.cr[0]][plane.cr[1] + i].z);
	}
	glEnd();
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= length; i++)
	{
		glVertex3f(pointsMesh[plane.cr[0] + i][plane.cr[1] + length].x, pointsMesh[plane.cr[0] + i][plane.cr[1] + length].y, pointsMesh[plane.cr[0] + i][plane.cr[1] + length].z);
	}
	glEnd();
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= length; i++)
	{
		glVertex3f(pointsMesh[plane.cr[0] + length][plane.cr[1] + length - i].x, pointsMesh[plane.cr[0] + length][plane.cr[1] + length - i].y, pointsMesh[plane.cr[0] + length][plane.cr[1] + length - i].z);
	}
	glEnd();
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= length; i++)
	{
		glVertex3f(pointsMesh[plane.cr[0] + length - i][plane.cr[1]].x, pointsMesh[plane.cr[0] + length - i][plane.cr[1]].y, pointsMesh[plane.cr[0] + length - i][plane.cr[1]].z);
	}
	glEnd();
}
void isRealSmall(std::vector<std::vector<Vector3d>> &pointsMesh, DividedPlane *planeArr, DividedPlane plane, double myEPS) {
	if (plane.eps > myEPS) {
		drawLine(pointsMesh, plane);

		if (plane.child1 != -1) {
			isRealSmall(pointsMesh, planeArr, planeArr[plane.child1], myEPS);
			isRealSmall(pointsMesh, planeArr, planeArr[plane.child2], myEPS);
			isRealSmall(pointsMesh, planeArr, planeArr[plane.child3], myEPS);
			isRealSmall(pointsMesh, planeArr, planeArr[plane.child4], myEPS);
		}
	}
}
void checkEPS(std::vector<std::vector<Vector3d>> &pointsMesh, DividedPlane *planeArr, double myEPS) {
	drawLine(pointsMesh, planeArr[0]);
	drawLine(pointsMesh, planeArr[1]);
	drawLine(pointsMesh, planeArr[2]);
	drawLine(pointsMesh, planeArr[3]);
	isRealSmall(pointsMesh, planeArr, planeArr[0], myEPS);
	isRealSmall(pointsMesh, planeArr, planeArr[1], myEPS);
	isRealSmall(pointsMesh, planeArr, planeArr[2], myEPS);
	isRealSmall(pointsMesh, planeArr, planeArr[3], myEPS);

}


//drawLine(planeArr[0].lu, planeArr[0].ld, planeArr[0].ru, planeArr[0].rd);
//drawLine(planeArr[1].lu, planeArr[1].ld, planeArr[1].ru, planeArr[1].rd);
//drawLine(planeArr[2].lu, planeArr[2].ld, planeArr[2].ru, planeArr[2].rd);
//drawLine(planeArr[3].lu, planeArr[3].ld, planeArr[3].ru, planeArr[3].rd);