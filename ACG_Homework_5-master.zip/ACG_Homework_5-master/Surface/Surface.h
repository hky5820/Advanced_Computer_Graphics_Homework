#ifndef _Surface_H_
#define _Surface_H_

#define PRECISION   1e-5
#define small_number         1e-6        /* data type is float */
#define RES 50

typedef float Point[3];

typedef struct BicubicBezierSurface
{
	Point control_pts[4][4];
} BicubicBezierSurface;

#ifdef DEBUG
void PRINT_CTRLPTS(CubicBezierSurface* crv);
#else
#   define PRINT_CTRLPTS(X)
#endif

#define SET_PT3(V, V1, V2, V3) do { (V)[0] = (V1); (V)[1] = (V2); (V)[2] = (V3); } while (0)

void evaluate(const BicubicBezierSurface *Surface, const float t1, const float t2, Point value);
void evaluatePic(const float surface[RES + 1][RES + 1][3], int **Image_Monotonic, float pic[RES + 1][RES + 1][3]);

#endif /* _Surface_H_ */
