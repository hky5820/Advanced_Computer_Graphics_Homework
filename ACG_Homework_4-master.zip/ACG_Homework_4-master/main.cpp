/*
A : Scale Up
S : Scale Down
D : Frequency Up
F : Frequency Down
C : Curve Draw Control
V : Sin Wave Draw Control
L : Line or Strip
Q : Increase 'a'
W : Decrease 'a'
E : Increase 'b'
R : Decrease 'b'
T : Counter Clock Wise Rotation 
Y : Clock Wise Rotation
G : On / Off Collision Check Mode
H : On / Off Point Mode
1 : Decrease Depth
2 : Increase Depth 
*/

#include <glut.h>
#include <stdlib.h>
#include "curve.h"
#include <stdio.h>
#include <cmath>
#include <float.h>
#include <string.h>
#include <vector>

CubicBezierCurve curve;
GLsizei width = 640, height = 480;
int edit_ctrlpts_idx = -1;
bool isDrawControlMesh = false;
bool isDottedLine = false;
bool isDrawSin = true;
bool isDrawEllipse = false;
bool isEllipseCollisionCheck = true;
bool isPoint = true;
REAL naturalNumber = 8;
REAL scaleFactor = 64;
REAL a = 62;
REAL b = 32;
REAL rad = 0;

int depth = 0;
int startIndex = 0;
int countInDepth = pow(2, depth);

int hit_index(CubicBezierCurve *curve, int x, int y)
{
	for (int i = 0; i < 4; i++)
	{
		REAL tx = curve->control_pts[i][0] - x;
		REAL ty = curve->control_pts[i][1] - y;
		if ((tx * tx + ty * ty) < 30) return i;
	}
	return -1;
}
void init()
{
	SET_PT2(curve.control_pts[0], 50, 100);
	SET_PT2(curve.control_pts[1], 200, 300);
	SET_PT2(curve.control_pts[2], 400, 300);
	SET_PT2(curve.control_pts[3], 550, 100);

	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0, width, 0, height);
	
}
void reshape_callback(GLint nw, GLint nh)
{
	width = nw;
	height = nh;
	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, width, 0, height);
}

void display_callback()
{
	/* curve */
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3ub(0, 0, 0);
	glLineWidth(1);
	if (isDottedLine)
		glBegin(GL_LINES);
	else
		glBegin(GL_LINE_STRIP);

	int originIndex;

	for (int i = 0; i <= RES; i++)
	{
		originIndex = i;
		Point pt;
		const REAL t = (REAL)i / (REAL)RES;
		evaluate(&curve, t, pt, originIndex);
		glVertex2f(pt[0], pt[1]);
	}
	glEnd();

	if (isDrawEllipse) {
		if (a <= 0) {
			a += 8;
		}
		if (b <= 0) {
			b += 8;
		}
	
		Point totalXY[2900] = { 0, };
		Point upperEllipseXY[1050] = { 0, };
		Point lower_Ellipse_XY[1050] = { 0, };
		Point curveXY[1050] = { 0, };

		int totalIndex = 0;

		/*Calculate Upper XY*/
		for (int i = 0; i <= RES; i++) {
			originIndex = i;
			Point pt, upperXY;
			const REAL t = (REAL)i / (REAL)RES;
			ellipseUpper(&curve, t, originIndex, upperXY, a, b, rad);
			upperEllipseXY[i][0] = upperXY[0]; upperEllipseXY[i][1] = upperXY[1];
			evaluate(&curve, t, pt, originIndex);
			curveXY[i][0] = pt[0]; curveXY[i][1] = pt[1];
		}

		/*Calculate Lower XY*/
		for (int i = 0; i <= RES; i++) {
			originIndex = i;
			Point lowerXY;
			const REAL t = (REAL)i / (REAL)RES;
			ellipseLower(&curve, t, originIndex, lowerXY, a, b, rad);
			lower_Ellipse_XY[i][0] = lowerXY[0];
			lower_Ellipse_XY[i][1] = lowerXY[1];
		}

		/*Calculate Left & Right Ellipse*/
		int leftDrawCount = 0;
		int rightDrawCount = 0;
		Point leftEllipseXY[360] = { 0, };
		Point rightEllipseXY[360] = { 0, };
		leftEllipse(&curve, a, b, rad, leftDrawCount, leftEllipseXY);
		rightEllipse(&curve, a, b, rad, rightDrawCount, rightEllipseXY);

		if (isEllipseCollisionCheck) {
			if (isPoint) {
				/*Calculate Collision Each*/
				for (int curveIndex = 0; curveIndex <= RES; curveIndex++) {
					REAL curveX = curveXY[curveIndex][0];
					REAL curveY = curveXY[curveIndex][1];
					for (int i = 0; i <= RES; i++) {
						REAL upperX = upperEllipseXY[i][0] - curveX;
						REAL upperY = upperEllipseXY[i][1] - curveY;
						REAL lowerX = lower_Ellipse_XY[i][0] - curveX;
						REAL lowerY = lower_Ellipse_XY[i][1] - curveY;
						REAL ellipseUpperValue = powf(upperX*cos(rad) + upperY * sin(rad), 2) / powf(a, 2)
							+ powf(upperX*sin(rad) - upperY * cos(rad), 2) / powf(b, 2);
						REAL ellipseLowerValue = powf(lowerX*cos(rad) + lowerY * sin(rad), 2) / powf(a, 2)
							+ powf(lowerX*sin(rad) - lowerY * cos(rad), 2) / powf(b, 2);

						if ((ellipseUpperValue - 1) < 0) {
							upperEllipseXY[i][0] = -1;
							upperEllipseXY[i][1] = -1;
						}
						if ((ellipseLowerValue - 1) < 0) {
							lower_Ellipse_XY[i][0] = -1;
							lower_Ellipse_XY[i][1] = -1;
						}
					}
					for (int i = 0; i < leftDrawCount; i++) {
						REAL X = leftEllipseXY[i][0] - curveX;
						REAL Y = leftEllipseXY[i][1] - curveY;

						REAL ellipseValue = powf(X*cos(rad) + Y * sin(rad), 2) / powf(a, 2)
							+ powf(X*sin(rad) - Y * cos(rad), 2) / powf(b, 2);
						if ((ellipseValue - 1) < 0) {
							leftEllipseXY[i][0] = -1;
							leftEllipseXY[i][1] = -1;
						}
					}
					for (int i = 0; i < rightDrawCount; i++) {
						REAL X = rightEllipseXY[i][0] - curveX;
						REAL Y = rightEllipseXY[i][1] - curveY;

						REAL ellipseValue = powf(X*cos(rad) + Y * sin(rad), 2) / powf(a, 2)
							+ powf(X*sin(rad) - Y * cos(rad), 2) / powf(b, 2);
						if ((ellipseValue - 1) < 0) {
							rightEllipseXY[i][0] = -1;
							rightEllipseXY[i][1] = -1;
						}
					}
					for (int i = 0; i <= RES * 2 + leftDrawCount + rightDrawCount - 2; i++) {
						REAL X = totalXY[i][0] - curveX;
						REAL Y = totalXY[i][1] - curveY;

						REAL ellipseValue = powf(X*cos(rad) + Y * sin(rad), 2) / powf(a, 2)
							+ powf(X*sin(rad) - Y * cos(rad), 2) / powf(b, 2);
						if ((ellipseValue - 1) < 0) {
							totalXY[i][0] = -1;
							totalXY[i][1] = -1;
						}
					}
				}
				glColor3ub(0, 0, 255);
				glBegin(GL_POINTS);
				for (int i = 0; i <= RES; i++) {
					if ((upperEllipseXY[i][0] > 0) && (upperEllipseXY[i][1] > 0)) {
						glVertex2f(upperEllipseXY[i][0], upperEllipseXY[i][1]);
					}
				}
				glEnd();
				glColor3ub(255, 0, 0);
				glBegin(GL_POINTS);
				for (int i = 0; i <= RES; i++) {
					if ((lower_Ellipse_XY[i][0] > 0) && (lower_Ellipse_XY[i][1] > 0)) {
						glVertex2f(lower_Ellipse_XY[i][0], lower_Ellipse_XY[i][1]);
					}
				}
				glEnd();
				glColor3ub(255, 0, 255);
				glBegin(GL_POINTS);
				for (int i = 0; i < leftDrawCount; i++) {
					if ((leftEllipseXY[i][0] > 0) && (leftEllipseXY[i][1] > 0)) {
						glVertex2f(leftEllipseXY[i][0], leftEllipseXY[i][1]);
					}
				}
				glEnd();
				glColor3ub(0, 0, 0);
				glBegin(GL_POINTS);
				for (int i = 0; i < rightDrawCount; i++) {
					if ((rightEllipseXY[i][0] > 0) && (rightEllipseXY[i][1] > 0)) {
						glVertex2f(rightEllipseXY[i][0], rightEllipseXY[i][1]);
					}
				}
				glEnd();
			}
			else {
				for (int i = 0; i <= RES; i++) {
					if (upperEllipseXY[i][0] > 0 && upperEllipseXY[i][1] > 0) {
						totalXY[totalIndex][0] = upperEllipseXY[i][0];
						totalXY[totalIndex][1] = upperEllipseXY[i][1];
						totalIndex++;
					}
				}
				for (int i = rightDrawCount - 2; i >= 1; i--) {
					if (rightEllipseXY[i][0] > 0 && rightEllipseXY[i][1] > 0) {
						totalXY[totalIndex][0] = rightEllipseXY[i][0];
						totalXY[totalIndex][1] = rightEllipseXY[i][1];
						totalIndex++;
					}
				}
				for (int i = RES; i >= 0; i--) {
					if (lower_Ellipse_XY[i][0] > 0 && lower_Ellipse_XY[i][1] > 0) {
						totalXY[totalIndex][0] = lower_Ellipse_XY[i][0];
						totalXY[totalIndex][1] = lower_Ellipse_XY[i][1];
						totalIndex++;
					}
				}
				for (int i = leftDrawCount - 2; i >= 1; i--) {
					if (leftEllipseXY[i][0] > 0 && leftEllipseXY[i][1] > 0) {
						totalXY[totalIndex][0] = leftEllipseXY[i][0];
						totalXY[totalIndex][1] = leftEllipseXY[i][1];
						totalIndex++;
					}
				}

				for (int curveIndex = 0; curveIndex <= RES; curveIndex++) {
					REAL curveX = curveXY[curveIndex][0];
					REAL curveY = curveXY[curveIndex][1];

					for (int i = 0; i <= RES * 2 + leftDrawCount + rightDrawCount - 2; i++) {
						REAL X = totalXY[i][0] - curveX;
						REAL Y = totalXY[i][1] - curveY;

						REAL ellipseValue = powf(X*cos(rad) + Y * sin(rad), 2) / powf(a, 2)
							+ powf(X*sin(rad) - Y * cos(rad), 2) / powf(b, 2);
						if ((ellipseValue - 1) < 0) {
							totalXY[i][0] = -1;
							totalXY[i][1] = -1;
						}
					}

				}
				glColor3ub(255, 0, 255);
				glBegin(GL_LINE_STRIP);
				for (int i = 0; i <= RES * 2 + leftDrawCount + rightDrawCount - 3; i++) {
					if ((totalXY[i][0] > 0) && (totalXY[i][1] >0)) {
						glVertex2f(totalXY[i][0], totalXY[i][1]);
					}
				}
				glEnd();
			}
		}
		else {
			glColor3ub(255, 0, 255);
			glBegin(GL_LINE_STRIP);
			for (int i = 0; i <= RES; i++) {
				glVertex2f(upperEllipseXY[i][0], upperEllipseXY[i][1]);
			}
			glEnd();

			glColor3ub(255, 0, 255);
			glBegin(GL_LINE_STRIP);
			for (int i = 0; i <= RES; i++) {
				glVertex2f(lower_Ellipse_XY[i][0], lower_Ellipse_XY[i][1]);
			}
			glEnd();
			glColor3ub(255, 0, 255);
			glBegin(GL_LINE_STRIP);
			for (int i = 0; i < leftDrawCount; i++) {
				if ((leftEllipseXY[i][0] > 0) && (leftEllipseXY[i][1] > 0)) {
					glVertex2f(leftEllipseXY[i][0], leftEllipseXY[i][1]);
				}
			}
			glEnd();
			glColor3ub(255, 0, 255);
			glBegin(GL_LINE_STRIP);
			for (int i = 0; i < rightDrawCount; i++) {
				if ((rightEllipseXY[i][0] > 0) && (rightEllipseXY[i][1] > 0)) {
					glVertex2f(rightEllipseXY[i][0], rightEllipseXY[i][1]);
				}
			}
			glEnd();

		}
	}

	if (isDrawSin)
	{
		Point sinSegment_XY[RES + 1] = { 0, };
		Point leftCircle[720] = { 0, };
		Point rightCircle[720] = { 0, };

		if (depth < 0) {
			depth = 0;
			startIndex = 0;
		}
		else if (depth > log2(RES + 1)) {
			depth -= 1;
			startIndex -= countInDepth;
		}

		countInDepth = pow(4, depth);

		/* Get Sin Wave XY */
		glColor3ub(255, 0, 255);
		glLineWidth(3);
		glPointSize(20);
		if (isDottedLine)
			glBegin(GL_LINES);
		else
			glBegin(GL_LINE_STRIP);
		for (int i = 0; i <= RES; i++) {
			originIndex = i;
			const REAL t = (REAL)i / (REAL)RES;
			sinEvalute(&curve, t, sinSegment_XY[i], originIndex, naturalNumber, scaleFactor);
			glVertex2f(sinSegment_XY[i][0], sinSegment_XY[i][1]);
		}
		glEnd();

		/* Calculate Leaf Node */
		int gapToNext = 1; int nodeCount = 1;
		TreeNode *nodeArr = new TreeNode[2 * RES - 1];
		for (int i = 0; i < RES; i += gapToNext) {
			int newIndex = 2 * RES - 1 - nodeCount;

			nodeArr[newIndex].startIndex = i;
			nodeArr[newIndex].endIndex = i + gapToNext;
			nodeArr[newIndex].leftChild = NULL;
			nodeArr[newIndex].rightChild = NULL;
			nodeArr[newIndex].radius = 0;
			nodeArr[newIndex].parent = NULL;
			nodeCount++;
		}
		gapToNext *= 2;

		/* Calculate Nodes on The Leaf Node */
		if (RES != 1) {
			Point midPoint; Point leftPoint, rightPoint;
			Point3 line;
			REAL lineToPoint; REAL maxRadius;

			/* Calculate Each Depth */
			while (1) {
				for (int i = 0; i < RES; i += gapToNext) {
					int newIndex = 2 * RES - 1 - nodeCount;

					nodeArr[newIndex].startIndex = i;
					nodeArr[newIndex].endIndex = i + gapToNext;

					leftPoint[0] = sinSegment_XY[i][0]; leftPoint[1] = sinSegment_XY[i][1];
					rightPoint[0] = sinSegment_XY[i + gapToNext][0]; rightPoint[1] = sinSegment_XY[i + gapToNext][1];
					midPoint[0] = sinSegment_XY[(2 * i + gapToNext) / 2][0]; midPoint[1] = sinSegment_XY[(2 * i + gapToNext) / 2][1];

					nodeArr[newIndex].leftChild = 2 * newIndex + 1;
					nodeArr[newIndex].rightChild = 2 * newIndex + 2;

					nodeArr[2 * newIndex + 1].parent = newIndex;
					nodeArr[2 * newIndex + 2].parent = newIndex;

					/* Calculate Radius */
					cross(leftPoint, rightPoint, line);
					int leftIndex = nodeArr[newIndex].leftChild;
					int rightIndex = nodeArr[newIndex].rightChild;
					maxRadius = std::fmax(nodeArr[leftIndex].radius, nodeArr[rightIndex].radius);
					nodeArr[newIndex].radius = fabs(line[0] * midPoint[0] + line[1] * midPoint[1] + line[2]) / sqrtf(powf(line[0], 2) + powf(line[1], 2)) + maxRadius;

					nodeCount++;
				}
				if (gapToNext == RES) {
					nodeArr[0].parent = -1;
					break;
				}
				gapToNext *= 2;
			}
		}
		
		/* Draw BVH */
		bvhDraw(4, nodeArr, leftCircle, rightCircle);
		bvhDraw(5, nodeArr, leftCircle, rightCircle);
		self_Intersection(nodeArr[0], nodeArr);
		printf("===========================================\n\n");
		delete[] nodeArr;

		
	}



	/* control mesh */
	if (isDrawControlMesh)
	{
		glColor3ub(255, 0, 0);
		glBegin(GL_LINE_STRIP);
		for (int i = 0; i < 4; i++)
		{
			REAL *pt = curve.control_pts[i];
			glVertex2f(pt[0], pt[1]);
		}
		glEnd();
	}

	/* control pts */
	glColor3ub(0, 0, 255);
	glPointSize(10.0);
	glBegin(GL_POINTS);
	for (int i = 0; i < 4; i++)
	{
		REAL *pt = curve.control_pts[i];
		glVertex2f(pt[0], pt[1]);
	}
	glEnd();
	glutSwapBuffers();
}

// void glutMouseFunc(void (*func)(int button, int state, int x, int y));
void mouse_callback(GLint button, GLint action, GLint x, GLint y)
{
	if (GLUT_LEFT_BUTTON == button)
	{
		switch (action)
		{
		case GLUT_DOWN:
			edit_ctrlpts_idx = hit_index(&curve, x, height - y);
			break;
		case GLUT_UP:
			edit_ctrlpts_idx = -1;
			break;
		default: break;
		}
	}
	glutPostRedisplay();
}

// void glutMotionFunc(void (*func)(int x, int y));
void mouse_move_callback(GLint x, GLint y)
{
	if (edit_ctrlpts_idx != -1)
	{
		curve.control_pts[edit_ctrlpts_idx][0] = x;
		curve.control_pts[edit_ctrlpts_idx][1] = height - y;
	}
	glutPostRedisplay();
}

// void glutKeyboardFunc(void (*func)(unsigned char key, int x, int y));
void keyboard_callback(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'i': case 'I':
		SET_PT2(curve.control_pts[0], 50, 100);
		SET_PT2(curve.control_pts[1], 200, 300);
		SET_PT2(curve.control_pts[2], 400, 300);
		SET_PT2(curve.control_pts[3], 550, 100);
		rad = 0;
		a = 62;
		b = 32;
		naturalNumber = 8;
		scaleFactor = 64;
		break;
	case 'l': case 'L':
		isDottedLine ^= true;
		break;
	case 'c': case 'C':
		isDrawControlMesh ^= true;
		break;
	case 'g': case 'G':
		isEllipseCollisionCheck ^= true;
		break;
	case 'h': case 'H':
		isPoint ^= true;
		break;
	case 'v': case 'V':
		isDrawSin ^= true;
		break;
	case 'x': case 'X':
		isDrawEllipse ^= true;
		break;
	case (27): exit(0); break;
	case 'd': case 'D':
		naturalNumber *= 2;
		break;
	case 'f': case 'F':
		naturalNumber /= 2;
		break;
	case 'a': case 'A':
		scaleFactor *= 2;
		break;
	case 's': case 'S':
		scaleFactor /= 2;
		break;
	case 'q': case 'Q':
		a += 8;
		break;
	case 'w': case 'W':
		a -= 8;
		break;
	case 'e': case 'E':
		b += 8;
		break;
	case 'r': case'R':
		b -= 8;
		break;
	case 't': case'T':
		rad += PI / 45;
		break;
	case 'y': case'Y':
		rad -= PI / 45;
		break;
	case '1':
		depth -= 1;
		startIndex -= countInDepth/2;
		break;
	case '2':
		depth += 1;
		startIndex += countInDepth;
		break;


	default: break;
	}
	glutPostRedisplay();
}

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowSize(width, height);
	glutCreateWindow("Bezier Editor");
	/*for (int i = 0; i < 2; i++) {
		countInDepth = pow(2, depth);
		depth += 1;
		startIndex += countInDepth;
	}*/

	init();
	glutReshapeFunc(reshape_callback);
	glutMouseFunc(mouse_callback);
	glutMotionFunc(mouse_move_callback);
	glutDisplayFunc(display_callback);
	glutKeyboardFunc(keyboard_callback);
	glutMainLoop();

	return 0;
}
