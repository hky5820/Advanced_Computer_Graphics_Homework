#ifndef _CURVE_H_
#define _CURVE_H_

#define PRECISION   1e-5
#define EPS         1e-6        /* data type is float */
#define INFINITY    FLT_MAX
/* x~1024 */
#define RES 512

const double PI = 3.141592653589793238463;

typedef double REAL;
typedef REAL  Point[2];
typedef REAL  Point3[3];

typedef struct CubicBezierCurve
{
	Point control_pts[4];
} CubicBezierCurve;

typedef struct TreeNode {
	int startIndex;
	int endIndex;
	REAL radius;
	int leftChild;
	int rightChild;
	int parent;
}TreeNode;

typedef struct Result_distance {
	double *pA;
	double *pB;
	double d;
}Result_distance;

#ifdef DEBUG
void PRINT_CTRLPTS(CubicBezierCurve* crv);
#else
#   define PRINT_CTRLPTS(X)
#endif

#define SET_PT2(V, V1, V2) do { (V)[0] = (V1); (V)[1] = (V2); } while (0)

void evaluate(const CubicBezierCurve *curve, const REAL t, Point value, int index);
void sinEvalute(const CubicBezierCurve *curve, const REAL t, Point sinWave, int index, REAL naturalNumber, REAL scaleFactor);
void intersection(int index, int &check, Point buf[RES]);
void ellipseUpper(const CubicBezierCurve *curve, const REAL t, int index, Point upperXY, REAL a, REAL b, REAL rad);
void ellipseLower(const CubicBezierCurve *curve, const REAL t, int index, Point lowerXY, REAL a, REAL b, REAL rad);
void upperEllipseSelfIntersection(int upperEllipseIndex, int &isInterOccur, Point interXY[RES]);
void lowerEllipseSelfIntersection(int upperEllipseIndex, int &isInterOccur, Point interXY[RES]);
void ellipseCrossIntersection(int upperEllipseIndex, int &isInterOccur, Point interXY[RES]);
void leftEllipse(const CubicBezierCurve *curve, REAL a, REAL b, REAL rad, int &leftDrawCount, Point leftHalfEllipseXY[360]);
void rightEllipse(const CubicBezierCurve *curve, REAL a, REAL b, REAL rad, int &rightDrawCount, Point rightHalfEllipseXY[360]);
void leftEllipseIntersection(int leftEllipseIndex, int &isInterOccur, Point interXY[360]);
void rightEllipseIntersection(int leftEllipseIndex, int &isInterOccur, Point interXY[360]);
void leftRightIntersection(int leftEllipseIndex, int &isInterOccur, Point interXY[360], int rightDrawCount);
void cross(Point V1, Point V2, Point3 result);
void bvhUpper(Point startPoint, Point endPoint, REAL radius, Point startUpperXY, Point endUpperXY);
void bvhLower(Point startPoint, Point endPoint, REAL radius, Point startLowerXY, Point endLowerXY);
void bvhDraw(int depth, TreeNode nodeArr[2 * RES - 1], Point leftCircle[720], Point rightCircle[720]);
void self_Intersection(const TreeNode node, const TreeNode nodeArr[2 * RES - 1]);
Result_distance* closestDistanceBetweenLines(double* a0, double* a1, double* b0, double* b1, int clampAll, int clampA0, int clampA1, int clampB0, int clampB1);

#endif /* _CURVE_H_ */

