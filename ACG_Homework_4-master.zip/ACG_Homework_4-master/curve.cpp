#include "curve.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <glut.h>
#include <float.h>
#include <string.h>

enum XYZ { X = 0, Y = 1, Z };

#define SET_VECTOR2(V, V1, V2)          do { (V)[X] = (V1); (V)[Y] = (V2); } while (0)
#define SET_VECTOR3(V, V1, V2, V3)          do { (V)[X] = (V1); (V)[Y] = (V2); (V)[Z] = (V3);} while (0)
#define COPY_PT(DST, SRC)               do { (DST)[X] = SRC[X]; (DST)[Y] = SRC[Y]; } while (0)
#define VECTOR2_X_SCALA_ADD(O, V, S)    do { O[X] += (S) * (V)[X]; O[Y] += (S) * (V)[Y]; } while (0)
#define PVECTOR2_X_SCALA_ADD(O, V1, V2, S)    do { O[X] += (S) * ((V2)[X]- (V1)[X]); O[Y] += (S) * ((V2)[Y] - (V1)[Y]); } while (0)

#ifdef DEBUG
void PRINT_CTRLPTS(CubicBezierCurve* crv) {
	int i;
	printf("curve %p\n[\n", crv);
	for (i = 0; i<4; ++i)
		printf("[%f, %f]\n", crv->control_pts[i][X], crv->control_pts[i][Y]);
	printf("]\n");
}
#endif

static Point curveXY[1050] = { 0, };
static Point sinXY[1050] = { 0, };
static Point upperEllipseXY[10500] = { 0, };
static Point lowerEllipseXY[10500] = { 0, };
static Point leftEllipseXY[360] = { 0, };
static Point rightEllipseXY[360] = { 0, };

void self_Intersection(const TreeNode node, const TreeNode nodeArr[2 * RES - 1]);
void collision_Detection(const int ind_left, const int ind_right, const TreeNode nodeArr[2 * RES - 1]);
bool overlap_Test(TreeNode left, TreeNode right);

void evaluate(const CubicBezierCurve *curve, const REAL t, Point value, int index)
{

	const REAL t_inv = 1.0f - t;
	const REAL t_inv_sq = t_inv * t_inv;
	const REAL t_sq = t * t;
	const REAL b0 = t_inv_sq * t_inv;
	const REAL b1 = 3 * t_inv_sq * t;
	const REAL b2 = 3 * t_inv * t_sq;
	const REAL b3 = t_sq * t;

	SET_VECTOR2(value, 0, 0);
	VECTOR2_X_SCALA_ADD(value, curve->control_pts[0], b0);
	VECTOR2_X_SCALA_ADD(value, curve->control_pts[1], b1);
	VECTOR2_X_SCALA_ADD(value, curve->control_pts[2], b2);
	VECTOR2_X_SCALA_ADD(value, curve->control_pts[3], b3);

	curveXY[index][0] = value[0];
	curveXY[index][1] = value[1];
}

void sinEvalute(const CubicBezierCurve *curve, const REAL t, Point sinWave, int index, REAL naturalNumber, REAL scaleFactor) {
	const REAL t_inv = 1.0f - t;
	const REAL t_inv_sq = t_inv * t_inv;
	const REAL t_sq = t * t;
	const REAL b0 = t_inv_sq;
	const REAL b1 = 2 * t_inv * t;
	const REAL b2 = t_sq;

	Point tangent;

	SET_VECTOR2(tangent, 0, 0);
	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[1], curve->control_pts[0], b0);
	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[2], curve->control_pts[1], b1);
	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[3], curve->control_pts[2], b2);

	REAL perpendicularX = 3 * tangent[Y];
	REAL perpendicularY = -3 * tangent[X];

	REAL perpendicularXY_sq = sqrt(pow(perpendicularX, 2) + pow(perpendicularY, 2));
	REAL normX = perpendicularX / perpendicularXY_sq;
	REAL normY = perpendicularY / perpendicularXY_sq;

	REAL differX = scaleFactor * sin(PI*naturalNumber*t) * normX;
	REAL differY = scaleFactor * sin(PI*naturalNumber*t) * normY;

	sinWave[0] = sinXY[index][0] = curveXY[index][0] + differX;
	sinWave[1] = sinXY[index][1] = curveXY[index][1] + differY;
}

void cross(Point V1, Point V2, Point3 result) {

	Point3 temp1, temp2;
	temp1[X] = V1[X]; temp1[Y] = V1[Y]; temp1[Z] = 1;
	temp2[X] = V2[X]; temp2[Y] = V2[Y]; temp2[Z] = 1;

	result[X] = temp1[Y] * temp2[Z] - temp1[Z] * temp2[Y];
	result[Y] = -temp1[X] * temp2[Z] + temp1[Z] * temp2[X];
	result[Z] = temp1[X] * temp2[Y] - temp1[Y] * temp2[X];
}

void linecross(Point V1, Point V2, Point3 result) {

	Point3 temp1, temp2;
	temp1[X] = V1[X]; temp1[Y] = V1[Y]; temp1[Z] = V1[Z];
	temp2[X] = V2[X]; temp2[Y] = V2[Y]; temp2[Z] = V2[Z];

	result[X] = temp1[Y] * temp2[Z] - temp1[Z] * temp2[Y];
	result[Y] = -temp1[X] * temp2[Z] + temp1[Z] * temp2[X];
	result[Z] = temp1[X] * temp2[Y] - temp1[Y] * temp2[X];
}

int ind = 0;

void intersection(int originIndex, int &isInterOccur, Point interXY[RES]) {

	Point3 originLine, otherLine;
	SET_VECTOR3(originLine, 0, 0, 0);
	SET_VECTOR3(otherLine, 0, 0, 0);

	REAL otherFromOrigin1, otherFromOrigin2, originFromOther1, originFromOther2;
	otherFromOrigin1 = otherFromOrigin2 = originFromOther1 = originFromOther2 = 0;

	cross(sinXY[originIndex], sinXY[originIndex + 1], originLine);

	ind = 0;

	for (int otherIndex = originIndex + 2; otherIndex < RES; otherIndex++) {

		cross(sinXY[otherIndex], sinXY[otherIndex + 1], otherLine);

		otherFromOrigin1 = originLine[X] * sinXY[otherIndex][0] + originLine[Y] * sinXY[otherIndex][1] + originLine[Z];
		otherFromOrigin2 = originLine[X] * sinXY[otherIndex + 1][0] + originLine[Y] * sinXY[otherIndex + 1][1] + originLine[Z];

		originFromOther1 = otherLine[X] * sinXY[originIndex][0] + otherLine[Y] * sinXY[originIndex][1] + otherLine[Z];
		originFromOther2 = otherLine[X] * sinXY[originIndex + 1][0] + otherLine[Y] * sinXY[originIndex + 1][1] + otherLine[Z];

		if ((otherFromOrigin1 * otherFromOrigin2) < 0 && (originFromOther1 * originFromOther2) < 0) {

			Point3 interPoint;
			SET_VECTOR3(interPoint, 0, 0, 0);
			linecross(originLine, otherLine, interPoint);

			interPoint[X] /= interPoint[Z];
			interPoint[Y] /= interPoint[Z];

			interXY[ind][0] = interPoint[X];
			interXY[ind][1] = interPoint[Y];

			ind += 1;
			isInterOccur = 1;
		}
	}
}

//void ellipseUpper(const CubicBezierCurve *curve, const REAL t, int index, Point upperXY, REAL a, REAL b, REAL rad) {
//	const REAL t_inv = 1.0f - t;
//	const REAL t_inv_sq = t_inv * t_inv;
//	const REAL t_sq = t * t;
//	const REAL b0 = t_inv_sq;
//	const REAL b1 = 2 * t_inv * t;
//	const REAL b2 = t_sq;
//
//	Point tangent;
//
//	SET_VECTOR2(tangent, 0, 0);
//	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[1], curve->control_pts[0], b0);
//	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[2], curve->control_pts[1], b1);
//	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[3], curve->control_pts[2], b2);
//
//	REAL tangentX = tangent[0];
//	REAL tangentY = tangent[1];
//
//	REAL square = powf(tangentX, 2) + powf(tangentY, 2);
//	REAL magnitude = sqrtf(square);
//
//	tangentX = tangentX / magnitude;
//	tangentY = tangentY / magnitude;
//
//	REAL similarity = DBL_MIN;
//	REAL finalXPosition; REAL finalYPosition;
//
//	for (REAL i = 0; i < 2 * PI; i += PI / 180) {
//
//		REAL ellipseXPosition = a * cos(i)*cos(rad) - b * sin(i)*sin(rad);
//		REAL ellipseYPosition = a * cos(i)*sin(rad) + b * sin(i)*cos(rad);
//		REAL ellipseTangentX = -a * sin(i)*cos(rad) - b * cos(i)*sin(rad);
//		REAL ellipseTangentY = -a * sin(i)*sin(rad) + b * cos(i)*cos(rad);
//
//		square = powf(ellipseTangentX, 2) + powf(ellipseTangentY, 2);
//		magnitude = sqrtf(square);
//
//		ellipseTangentX = ellipseTangentX / magnitude;
//		ellipseTangentY = ellipseTangentY / magnitude;
//
//		REAL productValue = tangentX * ellipseTangentX + tangentY * ellipseTangentY;
//
//		REAL checkSignX = tangentX * ellipseTangentX;
//		REAL checkSignY = tangentY * ellipseTangentY;
//		
//		if ((fabs(productValue - 1) < 0.001) && (similarity < productValue) && (checkSignX > 0 && checkSignY > 0)) {
//			finalXPosition = ellipseXPosition;
//			finalYPosition = ellipseYPosition;
//		}
//	}
//
//	upperEllipseXY[index][0] = upperXY[0] = finalXPosition + curveXY[index][0];
//	upperEllipseXY[index][1] = upperXY[1] = finalYPosition + curveXY[index][1];
//}
void ellipseUpper(const CubicBezierCurve *curve, const REAL t, int index, Point upperXY, REAL a, REAL b, REAL rad) {
	const REAL t_inv = 1.0f - t;
	const REAL t_inv_sq = t_inv * t_inv;
	const REAL t_sq = t * t;
	const REAL b0 = t_inv_sq;
	const REAL b1 = 2 * t_inv * t;
	const REAL b2 = t_sq;

	Point tangent;

	SET_VECTOR2(tangent, 0, 0);
	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[1], curve->control_pts[0], b0);
	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[2], curve->control_pts[1], b1);
	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[3], curve->control_pts[2], b2);

	REAL tangentX = tangent[0];
	REAL tangentY = tangent[1];

	REAL slope = tangentY / tangentX;

	REAL tangentI = (slope * b * sin(rad) + b * cos(rad)) / (-slope * a*cos(rad) + a * sin(rad));

	REAL I = atanf(tangentI);

	REAL ellipseXPosition = a * cos(I)*cos(rad) - b * sin(I)*sin(rad);
	REAL ellipseYPosition = a * cos(I)*sin(rad) + b * sin(I)*cos(rad);
	REAL inverseEllipseXPosition = -ellipseXPosition;
	REAL inverseEllipseYPosition = -ellipseYPosition;
	REAL ellipseTangentX = -a * sin(I)*cos(rad) - b * cos(I)*sin(rad);
	REAL ellipseTangentY = -a * sin(I)*sin(rad) + b * cos(I)*cos(rad);

	REAL checkSignX = tangentX * ellipseTangentX;
	REAL checkSignY = tangentY * ellipseTangentY;
	if (checkSignX >= 0 && checkSignY >= 0) {
		upperEllipseXY[index][0] = upperXY[0] = ellipseXPosition + curveXY[index][0];
		upperEllipseXY[index][1] = upperXY[1] = ellipseYPosition + curveXY[index][1];
	}
	else {
		upperEllipseXY[index][0] = upperXY[0] = inverseEllipseXPosition + curveXY[index][0];
		upperEllipseXY[index][1] = upperXY[1] = inverseEllipseYPosition + curveXY[index][1];
	}
}

//void ellipseLower(const CubicBezierCurve *curve, const REAL t, int index, Point lowerXY, REAL a, REAL b, REAL rad) {
//	const REAL t_inv = 1.0f - t;
//	const REAL t_inv_sq = t_inv * t_inv;
//	const REAL t_sq = t * t;
//	const REAL b0 = t_inv_sq;
//	const REAL b1 = 2 * t_inv * t;
//	const REAL b2 = t_sq;
//
//	Point tangent;
//
//	SET_VECTOR2(tangent, 0, 0);
//	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[1], curve->control_pts[0], b0);
//	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[2], curve->control_pts[1], b1);
//	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[3], curve->control_pts[2], b2);
//
//	REAL tangentX = tangent[0];
//	REAL tangentY = tangent[1];
//
//	REAL square = powf(tangentX, 2) + powf(tangentY, 2);
//	REAL magnitude = sqrtf(square);
//
//	tangentX = tangentX / magnitude;
//	tangentY = tangentY / magnitude;
//
//	REAL similarity = DBL_MAX;
//	REAL finalXPosition;
//	REAL finalYPosition;
//	
//
//	for (REAL i = 0; i < 2 * PI; i += PI / 180) {
//
//		REAL ellipseXPosition = a * cos(i)*cos(rad) - b * sin(i)*sin(rad);
//		REAL ellipseYPosition = a * cos(i)*sin(rad) + b * sin(i)*cos(rad);
//		REAL ellipseTangentX = -a * sin(i)*cos(rad) - b * cos(i)*sin(rad);
//		REAL ellipseTangentY = -a * sin(i)*sin(rad) + b * cos(i)*cos(rad);
//
//		
//
//		square = powf(ellipseTangentX, 2) + powf(ellipseTangentY, 2);
//		magnitude = sqrtf(square);
//
//		ellipseTangentX = ellipseTangentX / magnitude;
//		ellipseTangentY = ellipseTangentY / magnitude;
//
//		REAL productValue = tangentX * ellipseTangentX + tangentY * ellipseTangentY;
//
//		REAL checkSignX = tangentX * ellipseTangentX;
//		REAL checkSignY = tangentY * ellipseTangentY;
//
//		if ((fabs(productValue + 1) < 0.001) && (similarity > productValue) && (checkSignX < 0 && checkSignY < 0)) {
//			finalXPosition = ellipseXPosition;
//			finalYPosition = ellipseYPosition;
//		}
//	}
//	
//		lowerEllipseXY[index][0] = lowerXY[0] = finalXPosition + curveXY[index][0];
//		lowerEllipseXY[index][1] = lowerXY[1] = finalYPosition + curveXY[index][1];
//	
//}
void ellipseLower(const CubicBezierCurve *curve, const REAL t, int index, Point lowerXY, REAL a, REAL b, REAL rad) {
	const REAL t_inv = 1.0f - t;
	const REAL t_inv_sq = t_inv * t_inv;
	const REAL t_sq = t * t;
	const REAL b0 = t_inv_sq;
	const REAL b1 = 2 * t_inv * t;
	const REAL b2 = t_sq;

	Point tangent;

	SET_VECTOR2(tangent, 0, 0);
	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[1], curve->control_pts[0], b0);
	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[2], curve->control_pts[1], b1);
	PVECTOR2_X_SCALA_ADD(tangent, curve->control_pts[3], curve->control_pts[2], b2);

	REAL tangentX = tangent[0];
	REAL tangentY = tangent[1];

	REAL slope = tangentY / tangentX;

	REAL tangentI = (slope * b * sin(rad) + b * cos(rad)) / (-slope * a*cos(rad) + a * sin(rad));

	REAL I = atanf(tangentI);

	REAL ellipseXPosition = a * cos(I)*cos(rad) - b * sin(I)*sin(rad);
	REAL ellipseYPosition = a * cos(I)*sin(rad) + b * sin(I)*cos(rad);
	REAL inverseEllipseXPosition = -ellipseXPosition;
	REAL inverseEllipseYPosition = -ellipseYPosition;
	REAL ellipseTangentX = -a * sin(I)*cos(rad) - b * cos(I)*sin(rad);
	REAL ellipseTangentY = -a * sin(I)*sin(rad) + b * cos(I)*cos(rad);


	REAL checkSignX = tangentX * ellipseTangentX;
	REAL checkSignY = tangentY * ellipseTangentY;

	if (checkSignX <= 0 && checkSignY <= 0) {
		lowerEllipseXY[index][0] = lowerXY[0] = ellipseXPosition + curveXY[index][0];
		lowerEllipseXY[index][1] = lowerXY[1] = ellipseYPosition + curveXY[index][1];
	}
	else {
		lowerEllipseXY[index][0] = lowerXY[0] = inverseEllipseXPosition + curveXY[index][0];
		lowerEllipseXY[index][1] = lowerXY[1] = inverseEllipseYPosition + curveXY[index][1];
	}
}

//void leftEllipseDraw(const CubicBezierCurve *curve,REAL a, REAL b, REAL rad, int &leftDrawCount) {
//	Point ellipseCenter, upperXY, lowerXY;
//	evaluate(curve, 0, ellipseCenter, 0);
//	ellipseUpper(curve, 0, 0, upperXY, a, b, rad);
//	ellipseLower(curve, 0, 0, lowerXY, a, b, rad);
//	int start = 0;
//	ind = 0;
//	for (REAL i = 0; i < 3 * PI; i += PI / 180) {
//		REAL xPosition = ellipseCenter[0] + a * cos(i)*cos(rad) - b * sin(i)*sin(rad);
//		REAL yPosition = ellipseCenter[1] + a * cos(i)*sin(rad) + b * sin(i)*cos(rad);
//		REAL upperxdiffer = fabs(upperXY[0] - xPosition);
//		REAL upperydiffer = fabs(upperXY[1] - yPosition);
//		REAL lowerxdiffer = fabs(lowerXY[0] - xPosition);
//		REAL lowerydiffer = fabs(lowerXY[1] - yPosition);
//
//		if (upperxdiffer < 2.0 && upperydiffer < 2.0) {
//			start = 1;
//			glColor3ub(255, 0, 255);
//			glBegin(GL_LINE_STRIP);
//		}
//		else if (lowerxdiffer < 2.0 && lowerydiffer < 2.0) {
//			if (start == 1) {
//				glVertex2f(xPosition, yPosition);
//				leftEllipseXY[ind][0] = xPosition;
//				leftEllipseXY[ind][1] = yPosition;
//				leftDrawCount++;
//				glEnd();
//				break;
//			}
//			start = 0;
//		}
//		if (start) {
//			glVertex2f(xPosition, yPosition);
//			leftEllipseXY[ind][0] = xPosition;
//			leftEllipseXY[ind][1] = yPosition;
//			leftDrawCount++;
//			ind++;
//		}
//	}
//}
void leftEllipse(const CubicBezierCurve *curve, REAL a, REAL b, REAL rad, int &leftDrawCount, Point leftHalfEllipseXY[360]) {
	Point ellipseCenter, upperXY, lowerXY;
	evaluate(curve, 0, ellipseCenter, 0);
	ellipseUpper(curve, 0, 0, upperXY, a, b, rad);
	ellipseLower(curve, 0, 0, lowerXY, a, b, rad);
	int start = 0;
	ind = 0;
	for (REAL i = 0; i < 3 * PI; i += PI / 180) {
		REAL xPosition = ellipseCenter[0] + a * cos(i)*cos(rad) - b * sin(i)*sin(rad);
		REAL yPosition = ellipseCenter[1] + a * cos(i)*sin(rad) + b * sin(i)*cos(rad);
		REAL upperxdiffer = fabs(upperXY[0] - xPosition);
		REAL upperydiffer = fabs(upperXY[1] - yPosition);
		REAL lowerxdiffer = fabs(lowerXY[0] - xPosition);
		REAL lowerydiffer = fabs(lowerXY[1] - yPosition);

		if (upperxdiffer < 1.0 && upperydiffer < 1.0) {
			start = 1;
		}
		else if (lowerxdiffer < 1.0 && lowerydiffer < 1.0) {
			if (start == 1) {
				glVertex2f(xPosition, yPosition);
				leftHalfEllipseXY[ind][0] = leftEllipseXY[ind][0] = xPosition;
				leftHalfEllipseXY[ind][1] = leftEllipseXY[ind][1] = yPosition;
				leftDrawCount++;
				break;
			}
			start = 0;
		}
		if (start) {
			glVertex2f(xPosition, yPosition);
			leftHalfEllipseXY[ind][0] = leftEllipseXY[ind][0] = xPosition;
			leftHalfEllipseXY[ind][1] = leftEllipseXY[ind][1] = yPosition;
			leftDrawCount++;
			ind++;
		}
	}
}

void rightEllipse(const CubicBezierCurve *curve, REAL a, REAL b, REAL rad, int &rightDrawCount, Point rightHalfEllipseXY[360]) {
	Point ellipseCenter, upperXY, lowerXY;
	evaluate(curve, 1, ellipseCenter, RES);
	ellipseUpper(curve, 1, RES, upperXY, a, b, rad);
	ellipseLower(curve, 1, RES, lowerXY, a, b, rad);

	int start = 0;
	ind = 0;

	for (REAL i = 0; i < 3 * PI; i += PI / 180) {
		REAL xPosition = ellipseCenter[0] + a * cos(i)*cos(rad) - b * sin(i)*sin(rad);
		REAL yPosition = ellipseCenter[1] + a * cos(i)*sin(rad) + b * sin(i)*cos(rad);
		REAL upperxdiffer = fabs(upperXY[0] - xPosition);
		REAL upperydiffer = fabs(upperXY[1] - yPosition);
		REAL lowerxdiffer = fabs(lowerXY[0] - xPosition);
		REAL lowerydiffer = fabs(lowerXY[1] - yPosition);
		if (upperxdiffer < 1.0 && upperydiffer < 1.0) {
			if (start == 1) {
				glVertex2f(xPosition, yPosition);
				rightHalfEllipseXY[ind][0] = rightEllipseXY[ind][0] = xPosition;
				rightHalfEllipseXY[ind][1] = rightEllipseXY[ind][1] = yPosition;
				rightDrawCount++;
				break;
			}
			start = 0;
		}
		else if (lowerxdiffer < 1.0 && lowerydiffer < 1.0) {
			start = 1;
		}
		if (start) {
			glVertex2f(xPosition, yPosition);
			rightHalfEllipseXY[ind][0] = rightEllipseXY[ind][0] = xPosition;
			rightHalfEllipseXY[ind][1] = rightEllipseXY[ind][1] = yPosition;
			rightDrawCount++;
			ind++;
		}
	}
}


void bvhUpper(Point startPoint, Point endPoint, REAL radius, Point startUpperXY, Point endUpperXY) {
	REAL xDifference = endPoint[0] - startPoint[0];
	REAL yDifference = endPoint[1] - startPoint[1];
	
	REAL slope = yDifference / xDifference;

	REAL theta = atanf(-1 / slope);

	REAL xPosition = radius * cosf(theta);
	REAL yPosition = radius * sinf(theta);
	REAL inverseXPosition = -xPosition;
	REAL inverseYPosition = -yPosition;
	REAL circleTangentX = -sinf(theta);
	REAL circleTangentY = cosf(theta);

	REAL checkSignX = xDifference * circleTangentX;
	REAL checkSignY = yDifference * circleTangentY;

	if (checkSignX <= 0 && checkSignY <= 0) {
		startUpperXY[0] = startPoint[0] + xPosition;
		startUpperXY[1] = startPoint[1] + yPosition;
		endUpperXY[0] = endPoint[0] + xPosition;
		endUpperXY[1] = endPoint[1] + yPosition;
	}
	else {
		startUpperXY[0] = startPoint[0] + inverseXPosition;
		startUpperXY[1] = startPoint[1] + inverseYPosition;
		endUpperXY[0] = endPoint[0] + inverseXPosition;
		endUpperXY[1] = endPoint[1] + inverseYPosition;
	}
	


}

void bvhLower(Point startPoint, Point endPoint, REAL radius, Point startLowerXY, Point endLowerXY) {
	REAL xDifference = endPoint[0] - startPoint[0];
	REAL yDifference = endPoint[1] - startPoint[1];

	REAL slope = yDifference / xDifference;

	REAL theta = atanf(-1 / slope);

	REAL xPosition = radius * cosf(theta);
	REAL yPosition = radius * sinf(theta);
	REAL inverseXPosition = -xPosition;
	REAL inverseYPosition = -yPosition;
	REAL circleTangentX = -sinf(theta);
	REAL circleTangentY = cosf(theta);

	REAL checkSignX = xDifference * circleTangentX;
	REAL checkSignY = yDifference * circleTangentY;

	if (checkSignX >= 0 && checkSignY >= 0) {
		startLowerXY[0] = startPoint[0] + xPosition;
		startLowerXY[1] = startPoint[1] + yPosition;
		endLowerXY[0] = endPoint[0] + xPosition;
		endLowerXY[1] = endPoint[1] + yPosition;
	}
	else {
		startLowerXY[0] = startPoint[0] + inverseXPosition;
		startLowerXY[1] = startPoint[1] + inverseYPosition;
		endLowerXY[0] = endPoint[0] + inverseXPosition;
		endLowerXY[1] = endPoint[1] + inverseYPosition;
	}
}

void bvhLeftCircle(Point startPoint, Point startUpper, Point startLower, REAL radius, Point leftCircle[720], int &leftCircleCount) {
	int ind = 0;
	int start = 0;

	if (radius != 0) {
		if (radius < 1) {
			radius = 1;
		}
		for (REAL i = 0; i < 3 * PI; i += PI / 360) {
			REAL xPosition = radius * cosf(i) + startPoint[0];
			REAL yPosition = radius * sinf(i) + startPoint[1];
			REAL upperxdiffer = fabs(startUpper[0] - xPosition);
			REAL upperydiffer = fabs(startUpper[1] - yPosition);
			REAL lowerxdiffer = fabs(startLower[0] - xPosition);
			REAL lowerydiffer = fabs(startLower[1] - yPosition);

			if (upperxdiffer < 2.0 && upperydiffer < 2.0) {
				start = 1;
			}
			else if (lowerxdiffer < 2.0 && lowerydiffer < 2.0) {
				if (start == 1) {
					leftCircle[ind][0] = xPosition;
					leftCircle[ind][1] = yPosition;
					leftCircleCount++;
					break;
				}
				start = 0;
			}
			if (start) {
				leftCircle[ind][0] = xPosition;
				leftCircle[ind][1] = yPosition;
				leftCircleCount++;
				ind++;
			}
		}
	}
	
}
void bvhRightCircle(Point endPoint, Point endUpper, Point endLower, REAL radius, Point rightCircle[720], int &rightCircleCount) {
	int ind = 0;
	int start = 0;

	
	if (radius != 0) {
		if (radius < 1) {
			radius = 1;
		}
		for (REAL i = 0; i < 3 * PI; i += PI / 360) {
			REAL xPosition = radius * cosf(i) + endPoint[0];
			REAL yPosition = radius * sinf(i) + endPoint[1];
			REAL upperxdiffer = fabs(endUpper[0] - xPosition);
			REAL upperydiffer = fabs(endUpper[1] - yPosition);
			REAL lowerxdiffer = fabs(endLower[0] - xPosition);
			REAL lowerydiffer = fabs(endLower[1] - yPosition);

			if (upperxdiffer < 2.0 && upperydiffer < 2.0) {
				if (start == 1) {
					rightCircle[ind][0] = xPosition;
					rightCircle[ind][1] = yPosition;
					rightCircleCount++;
					break;
				}
				start = 0;
			}
			else if (lowerxdiffer < 2.0 && lowerydiffer < 2.0) {
				start = 1;
			}
			if (start) {
				rightCircle[ind][0] = xPosition;
				rightCircle[ind][1] = yPosition;
				rightCircleCount++;
				ind++;
			}
		}
	}
}
void upperEllipseSelfIntersection(int upperEllipseIndex, int &isInterOccur, Point interXY[RES]) {

	Point3 originLine, otherLine;
	SET_VECTOR3(originLine, 0, 0, 0);
	SET_VECTOR3(otherLine, 0, 0, 0);

	Point currentVector;
	REAL otherFromOrigin1, otherFromOrigin2, originFromOther1, originFromOther2;
	otherFromOrigin1 = otherFromOrigin2 = originFromOther1 = originFromOther2 = 0;


	cross(upperEllipseXY[upperEllipseIndex], upperEllipseXY[upperEllipseIndex + 1], originLine);

	ind = 0;

	for (int otherIndex = upperEllipseIndex + 2; otherIndex < RES; otherIndex++) {

		cross(upperEllipseXY[otherIndex], upperEllipseXY[otherIndex + 1], otherLine);

		otherFromOrigin1 = originLine[X] * upperEllipseXY[otherIndex][0] + originLine[Y] * upperEllipseXY[otherIndex][1] + originLine[Z];
		otherFromOrigin2 = originLine[X] * upperEllipseXY[otherIndex + 1][0] + originLine[Y] * upperEllipseXY[otherIndex + 1][1] + originLine[Z];

		originFromOther1 = otherLine[X] * upperEllipseXY[upperEllipseIndex][0] + otherLine[Y] * upperEllipseXY[upperEllipseIndex][1] + otherLine[Z];
		originFromOther2 = otherLine[X] * upperEllipseXY[upperEllipseIndex + 1][0] + otherLine[Y] * upperEllipseXY[upperEllipseIndex + 1][1] + otherLine[Z];

		if ((otherFromOrigin1 * otherFromOrigin2) < 0 && (originFromOther1 * originFromOther2) < 0) {

			Point3 interPoint;
			SET_VECTOR3(interPoint, 0, 0, 0);
			linecross(originLine, otherLine, interPoint);

			interPoint[X] /= interPoint[Z];
			interPoint[Y] /= interPoint[Z];

			interXY[ind][0] = interPoint[X];
			interXY[ind][1] = interPoint[Y];

			ind += 1;
			isInterOccur = 1;
		}
	}

}

void lowerEllipseSelfIntersection(int lowerEllipseIndex, int &isInterOccur, Point interXY[RES]) {

	Point3 originLine, otherLine;
	Point currentVector;
	SET_VECTOR3(originLine, 0, 0, 0);
	SET_VECTOR3(otherLine, 0, 0, 0);

	REAL otherFromOrigin1, otherFromOrigin2, originFromOther1, originFromOther2;
	otherFromOrigin1 = otherFromOrigin2 = originFromOther1 = originFromOther2 = 0;

	cross(lowerEllipseXY[lowerEllipseIndex], lowerEllipseXY[lowerEllipseIndex + 1], originLine);

	ind = 0;

	for (int otherIndex = lowerEllipseIndex + 2; otherIndex < RES; otherIndex++) {

		cross(lowerEllipseXY[otherIndex], lowerEllipseXY[otherIndex + 1], otherLine);

		otherFromOrigin1 = originLine[X] * lowerEllipseXY[otherIndex][0] + originLine[Y] * lowerEllipseXY[otherIndex][1] + originLine[Z];
		otherFromOrigin2 = originLine[X] * lowerEllipseXY[otherIndex + 1][0] + originLine[Y] * lowerEllipseXY[otherIndex + 1][1] + originLine[Z];

		originFromOther1 = otherLine[X] * lowerEllipseXY[lowerEllipseIndex][0] + otherLine[Y] * lowerEllipseXY[lowerEllipseIndex][1] + otherLine[Z];
		originFromOther2 = otherLine[X] * lowerEllipseXY[lowerEllipseIndex + 1][0] + otherLine[Y] * lowerEllipseXY[lowerEllipseIndex + 1][1] + otherLine[Z];

		if ((otherFromOrigin1 * otherFromOrigin2) < 0 && (originFromOther1 * originFromOther2) < 0) {

			Point3 interPoint;
			SET_VECTOR3(interPoint, 0, 0, 0);
			linecross(originLine, otherLine, interPoint);

			interPoint[X] /= interPoint[Z];
			interPoint[Y] /= interPoint[Z];

			interXY[ind][0] = interPoint[X];
			interXY[ind][1] = interPoint[Y];

			ind += 1;
			isInterOccur = 1;
		}
	}

}



void ellipseCrossIntersection(int upperEllipseIndex, int &isInterOccur, Point interXY[RES]) {

	Point3 originLine, otherLine;
	SET_VECTOR3(originLine, 0, 0, 0);
	SET_VECTOR3(otherLine, 0, 0, 0);

	REAL otherFromOrigin1, otherFromOrigin2, originFromOther1, originFromOther2;
	otherFromOrigin1 = otherFromOrigin2 = originFromOther1 = originFromOther2 = 0;

	cross(upperEllipseXY[upperEllipseIndex], upperEllipseXY[upperEllipseIndex + 1], originLine);

	ind = 0;

	for (int otherIndex = 1; otherIndex < RES; otherIndex++) {

		cross(lowerEllipseXY[otherIndex], lowerEllipseXY[otherIndex + 1], otherLine);

		otherFromOrigin1 = originLine[X] * lowerEllipseXY[otherIndex][0] + originLine[Y] * lowerEllipseXY[otherIndex][1] + originLine[Z];
		otherFromOrigin2 = originLine[X] * lowerEllipseXY[otherIndex + 1][0] + originLine[Y] * lowerEllipseXY[otherIndex + 1][1] + originLine[Z];

		originFromOther1 = otherLine[X] * upperEllipseXY[upperEllipseIndex][0] + otherLine[Y] * upperEllipseXY[upperEllipseIndex][1] + otherLine[Z];
		originFromOther2 = otherLine[X] * upperEllipseXY[upperEllipseIndex + 1][0] + otherLine[Y] * upperEllipseXY[upperEllipseIndex + 1][1] + otherLine[Z];

		if ((otherFromOrigin1 * otherFromOrigin2) < 0 && (originFromOther1 * originFromOther2) < 0) {

			Point3 interPoint;
			SET_VECTOR3(interPoint, 0, 0, 0);
			linecross(originLine, otherLine, interPoint);

			interPoint[X] /= interPoint[Z];
			interPoint[Y] /= interPoint[Z];

			interXY[ind][0] = interPoint[X];
			interXY[ind][1] = interPoint[Y];

			ind += 1;
			isInterOccur = 1;
		}
	}
}

void leftEllipseIntersection(int leftEllipseIndex, int &isInterOccur, Point interXY[360]) {
	Point3 originLine, otherLine;
	SET_VECTOR3(originLine, 0, 0, 0);
	SET_VECTOR3(otherLine, 0, 0, 0);

	REAL otherFromOrigin1, otherFromOrigin2, originFromOther1, originFromOther2;
	otherFromOrigin1 = otherFromOrigin2 = originFromOther1 = originFromOther2 = 0;

	cross(leftEllipseXY[leftEllipseIndex], leftEllipseXY[leftEllipseIndex + 1], originLine);

	ind = 0;

	for (int otherIndex = 1; otherIndex < RES - 1; otherIndex++) {

		cross(upperEllipseXY[otherIndex], upperEllipseXY[otherIndex + 1], otherLine);

		otherFromOrigin1 = originLine[X] * upperEllipseXY[otherIndex][0] + originLine[Y] * upperEllipseXY[otherIndex][1] + originLine[Z];
		otherFromOrigin2 = originLine[X] * upperEllipseXY[otherIndex + 1][0] + originLine[Y] * upperEllipseXY[otherIndex + 1][1] + originLine[Z];

		originFromOther1 = otherLine[X] * leftEllipseXY[leftEllipseIndex][0] + otherLine[Y] * leftEllipseXY[leftEllipseIndex][1] + otherLine[Z];
		originFromOther2 = otherLine[X] * leftEllipseXY[leftEllipseIndex + 1][0] + otherLine[Y] * leftEllipseXY[leftEllipseIndex + 1][1] + otherLine[Z];

		if ((otherFromOrigin1 * otherFromOrigin2) < 0 && (originFromOther1 * originFromOther2) < 0) {
			Point3 interPoint;
			SET_VECTOR3(interPoint, 0, 0, 0);
			linecross(originLine, otherLine, interPoint);

			interPoint[X] /= interPoint[Z];
			interPoint[Y] /= interPoint[Z];

			interXY[ind][0] = interPoint[X];
			interXY[ind][1] = interPoint[Y];
			ind += 1;
			isInterOccur = 1;
			break;
		}
	}
	for (int otherIndex = 1; otherIndex < RES - 1; otherIndex++) {

		cross(lowerEllipseXY[otherIndex], lowerEllipseXY[otherIndex + 1], otherLine);

		otherFromOrigin1 = originLine[X] * lowerEllipseXY[otherIndex][0] + originLine[Y] * lowerEllipseXY[otherIndex][1] + originLine[Z];
		otherFromOrigin2 = originLine[X] * lowerEllipseXY[otherIndex + 1][0] + originLine[Y] * lowerEllipseXY[otherIndex + 1][1] + originLine[Z];

		originFromOther1 = otherLine[X] * leftEllipseXY[leftEllipseIndex][0] + otherLine[Y] * leftEllipseXY[leftEllipseIndex][1] + otherLine[Z];
		originFromOther2 = otherLine[X] * leftEllipseXY[leftEllipseIndex + 1][0] + otherLine[Y] * leftEllipseXY[leftEllipseIndex + 1][1] + otherLine[Z];

		if ((otherFromOrigin1 * otherFromOrigin2) < 0 && (originFromOther1 * originFromOther2) < 0) {
			Point3 interPoint;
			SET_VECTOR3(interPoint, 0, 0, 0);
			linecross(originLine, otherLine, interPoint);

			interPoint[X] /= interPoint[Z];
			interPoint[Y] /= interPoint[Z];

			interXY[ind][0] = interPoint[X];
			interXY[ind][1] = interPoint[Y];

			ind += 1;
			isInterOccur = 1;
			break;
		}
	}
}

void rightEllipseIntersection(int leftEllipseIndex, int &isInterOccur, Point interXY[360]) {
	Point3 originLine, otherLine;
	SET_VECTOR3(originLine, 0, 0, 0);
	SET_VECTOR3(otherLine, 0, 0, 0);

	REAL otherFromOrigin1, otherFromOrigin2, originFromOther1, originFromOther2;
	otherFromOrigin1 = otherFromOrigin2 = originFromOther1 = originFromOther2 = 0;

	cross(rightEllipseXY[leftEllipseIndex], rightEllipseXY[leftEllipseIndex + 1], originLine);

	ind = 0;

	for (int otherIndex = 1; otherIndex < RES - 1; otherIndex++) {

		cross(upperEllipseXY[otherIndex], upperEllipseXY[otherIndex + 1], otherLine);

		otherFromOrigin1 = originLine[X] * upperEllipseXY[otherIndex][0] + originLine[Y] * upperEllipseXY[otherIndex][1] + originLine[Z];
		otherFromOrigin2 = originLine[X] * upperEllipseXY[otherIndex + 1][0] + originLine[Y] * upperEllipseXY[otherIndex + 1][1] + originLine[Z];

		originFromOther1 = otherLine[X] * rightEllipseXY[leftEllipseIndex][0] + otherLine[Y] * rightEllipseXY[leftEllipseIndex][1] + otherLine[Z];
		originFromOther2 = otherLine[X] * rightEllipseXY[leftEllipseIndex + 1][0] + otherLine[Y] * rightEllipseXY[leftEllipseIndex + 1][1] + otherLine[Z];

		if ((otherFromOrigin1 * otherFromOrigin2) < 0 && (originFromOther1 * originFromOther2) < 0) {
			Point3 interPoint;
			SET_VECTOR3(interPoint, 0, 0, 0);
			linecross(originLine, otherLine, interPoint);

			interPoint[X] /= interPoint[Z];
			interPoint[Y] /= interPoint[Z];

			interXY[ind][0] = interPoint[X];
			interXY[ind][1] = interPoint[Y];
			ind += 1;
			isInterOccur = 1;
			break;
		}
	}

	for (int otherIndex = 1; otherIndex < RES - 1; otherIndex++) {

		cross(lowerEllipseXY[otherIndex], lowerEllipseXY[otherIndex + 1], otherLine);

		otherFromOrigin1 = originLine[X] * lowerEllipseXY[otherIndex][0] + originLine[Y] * lowerEllipseXY[otherIndex][1] + originLine[Z];
		otherFromOrigin2 = originLine[X] * lowerEllipseXY[otherIndex + 1][0] + originLine[Y] * lowerEllipseXY[otherIndex + 1][1] + originLine[Z];

		originFromOther1 = otherLine[X] * rightEllipseXY[leftEllipseIndex][0] + otherLine[Y] * rightEllipseXY[leftEllipseIndex][1] + otherLine[Z];
		originFromOther2 = otherLine[X] * rightEllipseXY[leftEllipseIndex + 1][0] + otherLine[Y] * rightEllipseXY[leftEllipseIndex + 1][1] + otherLine[Z];

		if ((otherFromOrigin1 * otherFromOrigin2) < 0 && (originFromOther1 * originFromOther2) < 0) {
			Point3 interPoint;
			SET_VECTOR3(interPoint, 0, 0, 0);
			linecross(originLine, otherLine, interPoint);

			interPoint[X] /= interPoint[Z];
			interPoint[Y] /= interPoint[Z];

			interXY[ind][0] = interPoint[X];
			interXY[ind][1] = interPoint[Y];

			ind += 1;
			isInterOccur = 1;
			break;
		}
	}
}

void leftRightIntersection(int leftEllipseIndex, int &isInterOccur, Point interXY[360], int rightDrawCount) {
	Point3 originLine, otherLine;
	SET_VECTOR3(originLine, 0, 0, 0);
	SET_VECTOR3(otherLine, 0, 0, 0);

	REAL otherFromOrigin1, otherFromOrigin2, originFromOther1, originFromOther2;
	otherFromOrigin1 = otherFromOrigin2 = originFromOther1 = originFromOther2 = 0;

	cross(leftEllipseXY[leftEllipseIndex], leftEllipseXY[leftEllipseIndex + 1], originLine);

	ind = 0;

	for (int otherIndex = 0; otherIndex < rightDrawCount - 1; otherIndex++) {

		cross(rightEllipseXY[otherIndex], rightEllipseXY[otherIndex + 1], otherLine);

		otherFromOrigin1 = originLine[X] * rightEllipseXY[otherIndex][0] + originLine[Y] * rightEllipseXY[otherIndex][1] + originLine[Z];
		otherFromOrigin2 = originLine[X] * rightEllipseXY[otherIndex + 1][0] + originLine[Y] * rightEllipseXY[otherIndex + 1][1] + originLine[Z];

		originFromOther1 = otherLine[X] * leftEllipseXY[leftEllipseIndex][0] + otherLine[Y] * leftEllipseXY[leftEllipseIndex][1] + otherLine[Z];
		originFromOther2 = otherLine[X] * leftEllipseXY[leftEllipseIndex + 1][0] + otherLine[Y] * leftEllipseXY[leftEllipseIndex + 1][1] + otherLine[Z];

		if ((otherFromOrigin1 * otherFromOrigin2) < 0 && (originFromOther1 * originFromOther2) < 0) {
			Point3 interPoint;
			SET_VECTOR3(interPoint, 0, 0, 0);
			linecross(originLine, otherLine, interPoint);

			interPoint[X] /= interPoint[Z];
			interPoint[Y] /= interPoint[Z];

			interXY[ind][0] = interPoint[X];
			interXY[ind][1] = interPoint[Y];

			ind += 1;
			isInterOccur = 1;
		}
	}
}

void bvhDraw(int depth, TreeNode nodeArr[2 * RES - 1], Point leftCircle[720], Point rightCircle[720]) {
	int countInDepth = 0;
	int startIndex = 0;

	for (int i = 0; i < depth; i++) {
		countInDepth = pow(2, i);
		startIndex += countInDepth;
	}

	countInDepth = pow(2, depth);

	for (int i = startIndex; i < startIndex + countInDepth; i++) {
		int start = nodeArr[i].startIndex;
		int end = nodeArr[i].endIndex;
		REAL radius = nodeArr[i].radius;

		Point startPoint; Point endPoint;
		startPoint[0] = sinXY[start][0]; startPoint[1] = sinXY[start][1];
		endPoint[0] = sinXY[end][0]; endPoint[1] = sinXY[end][1];

		Point startUpperXY, endUpperXY, startLowerXY, endLowerXY;
		bvhUpper(startPoint, endPoint, radius, startUpperXY, endUpperXY);
		bvhLower(startPoint, endPoint, radius, startLowerXY, endLowerXY);

		int leftCircleCount = 0; int rightCircleCount = 0;
		bvhLeftCircle(startPoint, startUpperXY, startLowerXY, radius, leftCircle, leftCircleCount);
		bvhRightCircle(endPoint, endUpperXY, endLowerXY, radius, rightCircle, rightCircleCount);
		glColor3ub(0, 125, 255);
		glLineWidth(1);
		glPointSize(30);

		glBegin(GL_LINE_STRIP);

		glVertex2f(startUpperXY[0], startUpperXY[1]);
		glVertex2f(endUpperXY[0], endUpperXY[1]);

		for (int i = 0; i < leftCircleCount; i++) {
			if ((leftCircle[i][0] > 0) && (leftCircle[i][1] > 0)) {
				glVertex2f(leftCircle[i][0], leftCircle[i][1]);
			}
		}

		glVertex2f(startLowerXY[0], startLowerXY[1]);
		glVertex2f(endLowerXY[0], endLowerXY[1]);

		for (int i = 0; i < rightCircleCount; i++) {
			if ((rightCircle[i][0] > 0) && (rightCircle[i][1] > 0)) {
				glVertex2f(rightCircle[i][0], rightCircle[i][1]);
			}
		}
		glVertex2f(startUpperXY[0], startUpperXY[1]);
		glEnd();
	}


}

void self_Intersection(const TreeNode node, const TreeNode nodeArr[2 * RES - 1]) {
	int leftIndex = node.leftChild;
	int rightIndex = node.rightChild;
	int ind_left_child = nodeArr[leftIndex].leftChild; // Balance�� ������ �ֱ� ������ �� �ܰ� �Ʒ��� �ڽĵ� �� �ϳ��� NULL������ Check�ϸ� �ȴ�.
	
	if (ind_left_child != NULL) {
		collision_Detection(leftIndex, rightIndex, nodeArr);
		self_Intersection(nodeArr[leftIndex], nodeArr);
		self_Intersection(nodeArr[rightIndex], nodeArr);
	}
}
void leaf_Overlap_Test(const TreeNode left, const TreeNode right, const TreeNode nodeArr[2 * RES - 1]) {
	if (left.startIndex != right.endIndex) {
		Point3 line_left, line_right;
		Point ind_left_start, ind_left_end, ind_right_start, ind_right_end;

		ind_left_start[X] = sinXY[left.startIndex][X];
		ind_left_start[Y] = sinXY[left.startIndex][Y];
		ind_right_start[X] = sinXY[right.startIndex][X];
		ind_right_start[Y] = sinXY[right.startIndex][Y];


		ind_left_end[X] = sinXY[left.endIndex][X];
		ind_left_end[Y] = sinXY[left.endIndex][Y];
		ind_right_end[X] = sinXY[right.endIndex][X];
		ind_right_end[Y] = sinXY[right.endIndex][Y];
		
		cross(ind_left_start, ind_left_end, line_left);
		cross(ind_right_start, ind_right_end, line_right);


		double right_Start_In_Left, right_End_In_Left;
		double left_Start_In_Right, left_End_In_Right;


		right_Start_In_Left = line_left[X] * ind_right_start[X] + line_left[Y] * ind_right_start[Y] + line_left[Z];
		right_End_In_Left = line_left[X] * ind_right_end[X] + line_left[Y] * ind_right_end[Y] + line_left[Z];


		left_Start_In_Right = line_right[X] * ind_left_start[X] + line_right[Y] * ind_left_start[Y] + line_right[Z];
		left_End_In_Right = line_right[X] * ind_left_end[X] + line_right[Y] * ind_left_end[Y] + line_right[Z];
		if ((right_Start_In_Left * right_End_In_Left) < 0 && (left_Start_In_Right * left_End_In_Right) < 0) {

			Point3 intersection_Point;
			SET_VECTOR3(intersection_Point, 0, 0, 0);
			linecross(line_left, line_right, intersection_Point);

			intersection_Point[X] /= intersection_Point[Z];
			intersection_Point[Y] /= intersection_Point[Z];

			glColor3ub(255, 255, 0);
			glPointSize(7);
			glBegin(GL_POINTS);
			glVertex2f(intersection_Point[X], intersection_Point[Y]);
			glEnd();
		}
	}
}

void collision_Detection(const int ind_left, const int ind_right, const TreeNode nodeArr[2 * RES - 1]) {

	bool is_overlap; 
	
	int ind_left_leftChild = nodeArr[ind_left].leftChild;
	int ind_left_rightChild = nodeArr[ind_left].rightChild;
	int ind_right_leftChild = nodeArr[ind_right].leftChild;
	int ind_right_rightChild = nodeArr[ind_right].rightChild;

	if (ind_left_leftChild != NULL) {
		is_overlap = overlap_Test(nodeArr[ind_left], nodeArr[ind_right]);

		if (is_overlap) {
			collision_Detection(ind_left_leftChild, ind_right_leftChild, nodeArr);
			collision_Detection(ind_left_leftChild, ind_right_rightChild, nodeArr);
			collision_Detection(ind_left_rightChild, ind_right_leftChild, nodeArr);
			collision_Detection(ind_left_rightChild, ind_right_rightChild, nodeArr);
		}
	}
	else if (ind_left_leftChild == NULL) {
		leaf_Overlap_Test(nodeArr[ind_left], nodeArr[ind_right],nodeArr);
	}		
}

bool overlap_Test(const TreeNode left, const TreeNode right) {


	double a1[] = { sinXY[left.startIndex][X], sinXY[left.startIndex][Y], 0 };
	double a0[] = { sinXY[left.endIndex][X], sinXY[left.endIndex][Y], 0 };
	double b0[] = { sinXY[right.startIndex][X], sinXY[right.startIndex][Y], 0 };
	double b1[] = { sinXY[right.endIndex][X], sinXY[right.endIndex][Y], 0 };

	Result_distance* rd = closestDistanceBetweenLines(a0, a1, b0, b1, 1, 0, 0, 0, 0);

	double shortest_Distance = rd->d;
	double sum_Each_Radius = left.radius + right.radius;
	if (shortest_Distance <= sum_Each_Radius) {
		return true;
	}
	else {
		return false;
	}
}