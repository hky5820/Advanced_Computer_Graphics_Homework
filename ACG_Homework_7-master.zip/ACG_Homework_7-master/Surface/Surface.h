#include <vector>
#include "viewport.h"

#ifndef _Surface_H_
#define _Surface_H_

#define PRECISION   1e-5
#define EPS         1e-6        /* data type is double */
#define RES 1024
typedef double Point[3];
typedef int ColumnRow[2];

typedef struct BicubicBezierSurface
{
	Point control_pts[4][4];
} BicubicBezierSurface;

typedef struct DividedPlane {
	Vector3d lu;
	Vector3d ru;
	Vector3d ld;
	Vector3d rd;
	ColumnRow cr;
	int nextGap;

	double eps;

	int parent;
	int child1;
	int child2;
	int child3;
	int child4;
	int ind;
} DividedPlane;

#ifdef DEBUG
void PRINT_CTRLPTS(CubicBezierSurface* crv);
#else
#   define PRINT_CTRLPTS(X)
#endif

#define SET_PT3(V, V1, V2, V3) do { (V)[0] = (V1); (V)[1] = (V2); (V)[2] = (V3); } while (0)

void evaluate(const BicubicBezierSurface *Surface, const double t1, const double t2, Point value);
void evaluateMesh(const double surface[RES + 1][RES + 1][3],
	double r,
	std::vector<std::vector<Vector3d>> &uPartialDerivative,
	std::vector<std::vector<Vector3d>> &vPartialDerivative,
	std::vector<std::vector<Vector3d>> &mesh);
void makingTree(double points[RES + 1][RES + 1][3], DividedPlane *planeArr);
void checkEPS(std::vector<std::vector<Vector3d>> &pointsMesh, DividedPlane *planeArr, double myEPS);
void collisionDetection(DividedPlane *planeArr, DividedPlane *fixedPlaneArr);
#endif /* _Surface_H_ */
