#include "Surface.h"
#include "viewport.h"
#include "gjk.h"
#include <glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <cmath>
enum XYZ { X = 0, Y, Z };

#define COPY_PT(DST, SRC)               do { (DST)[X] = SRC[X]; (DST)[Y] = SRC[Y]; } while (0)
#define VECTOR3_X_SCALA_ADD(O, V, S)    do { O[X] += (S) * (V)[X]; O[Y] += (S) * (V)[Y]; O[Z] += (S) * (V)[Z]; } while (0)

#ifdef DEBUG
void PRINT_CTRLPTS(CubicBezierSurface* crv) {
	int i;
	printf("Surface %p\n[\n", crv);
	for (i=0; i<4; ++i)
		printf("[%f, %f]\n", crv->control_pts[i][X], crv->control_pts[i][Y]);
	printf("]\n");
}
#endif

void evaluate(const BicubicBezierSurface *Surface, const double t1, const double t2, Point value)
{
	const double t1_inv = 1.0f - t1;
	const double t1_inv_sq = t1_inv * t1_inv;
	const double t1_sq = t1 * t1;
	const double t2_inv = 1.0f - t2;
	const double t2_inv_sq = t2_inv * t2_inv;
	const double t2_sq = t2 * t2;

	double b[2][4];
	b[0][0] = t1_inv_sq * t1_inv;
	b[0][1] = 3 * t1_inv_sq * t1;
	b[0][2] = 3 * t1_inv * t1_sq;
	b[0][3] = t1_sq * t1;
	b[1][0] = t2_inv_sq * t2_inv;
	b[1][1] = 3 * t2_inv_sq * t2;
	b[1][2] = 3 * t2_inv * t2_sq;
	b[1][3] = t2_sq * t2;

	SET_PT3(value, 0, 0, 0);
	for (int i = 0; i < 4; i++)
	for (int j = 0; j < 4; j++)
		VECTOR3_X_SCALA_ADD(value, Surface->control_pts[i][j], b[0][i] * b[1][j]);
}

void evaluateMesh(const double surface[RES + 1][RES + 1][3],
	double r,
	std::vector<std::vector<Vector3d>> &uPartialDerivative,
	std::vector<std::vector<Vector3d>> &vPartialDerivative,
	std::vector<std::vector<Vector3d>> &mesh)
{

	for (int i = 0; i < RES; i++) {
		for (int j = 0; j < RES; j++) {
			uPartialDerivative[i][j].x = surface[i][j + 1][0] - surface[i][j][0];
			uPartialDerivative[i][j].y = surface[i][j + 1][1] - surface[i][j][1];
			uPartialDerivative[i][j].z = surface[i][j + 1][2] - surface[i][j][2];

			vPartialDerivative[i][j].x = surface[i + 1][j][0] - surface[i][j][0];
			vPartialDerivative[i][j].y = surface[i + 1][j][1] - surface[i][j][1];
			vPartialDerivative[i][j].z = surface[i + 1][j][2] - surface[i][j][2];
		}
	}

	Vector3d n;
	for (int i = 0; i < RES; i++) {
		for (int j = 0; j < RES; j++) {
			Vector3d uDev(uPartialDerivative[i][j].x, uPartialDerivative[i][j].y, uPartialDerivative[i][j].z);
			Vector3d vDev(vPartialDerivative[i][j].x, vPartialDerivative[i][j].y, vPartialDerivative[i][j].z);
			
			n.cross(uDev, vDev);
			n.normalize();

			mesh[i][j].x = surface[i][j][0] + r * n.x;
			mesh[i][j].y = surface[i][j][1] + r * n.y;
			mesh[i][j].z = surface[i][j][2] + r * n.z;

			if (j == RES-1) {
				mesh[i][RES].x = surface[i][RES][0] + r * n.x;
				mesh[i][RES].y = surface[i][RES][1] + r * n.y;
				mesh[i][RES].z = surface[i][RES][2] + r * n.z;
			}
		}
		if (i == RES - 1) {
			for (int ind = 0; ind <= RES; ind++) {
				mesh[RES][ind].x = surface[RES][ind][0] + r * n.x;
				mesh[RES][ind].y = surface[RES][ind][1] + r * n.y;
				mesh[RES][ind].z = surface[RES][ind][2] + r * n.z;
			}
		}
	}
}

double calculationEPS(std::vector<std::vector<Vector3d>> &pointsMesh, Vector3d lu, Vector3d ru, Vector3d rd, Vector3d ld, int columnStart, int rowStart, int heightNextGap) {
	double eps;
	double maxEPS = DBL_MIN;
	Vector3d biLinearSurf;
	double u, v;

	for (int i = 0; i < heightNextGap; i++) {
		u = (double)i / (double)heightNextGap;
		for (int j = 0; j < heightNextGap; j++) {
			v = (double)j / (double)heightNextGap;
			biLinearSurf.x = (1 - u)*(1 - v)*lu.x + u * (1 - v)* ld.x + (1 - u)* v * ru.x + u * v*rd.x;
			biLinearSurf.y = (1 - u)*(1 - v)*lu.y + u * (1 - v)* ld.y + (1 - u)* v * ru.y + u * v*rd.y;
			biLinearSurf.z = (1 - u)*(1 - v)*lu.z + u * (1 - v)* ld.z + (1 - u)* v * ru.z + u * v*rd.z;
			eps = powf(pointsMesh[columnStart + i][rowStart + j].x - biLinearSurf.x, 2)
				+ powf(pointsMesh[columnStart + i][rowStart + j].y - biLinearSurf.y, 2)
				+ powf(pointsMesh[columnStart + i][rowStart + j].z - biLinearSurf.z, 2);
			
			if (eps > maxEPS) {
				maxEPS = eps;
			}
		}
	}

	return maxEPS;
}

void insert(double points[RES + 1][RES + 1][3], DividedPlane &child, DividedPlane &parent, int childInd, int columnGap, int rowGap) {
	double calEPS;

	child.nextGap = parent.nextGap / 2;
	if (child.nextGap != 1) {
		child.child1 = (childInd + 1) * 4;
		child.child2 = (childInd + 1) * 4 + 1;
		child.child3 = (childInd + 1) * 4 + 2;
		child.child4 = (childInd + 1) * 4 + 3;
	}
	else {
		child.child1 = -1;
		child.child2 = -1;
		child.child3 = -1;
		child.child4 = -1;
	}


	child.ind = childInd;

	child.cr[0] = parent.cr[0] + columnGap;
	child.cr[1] = parent.cr[1] + rowGap;

	child.lu.set(points[child.cr[0]][child.cr[1]][0],
		points[child.cr[0]][child.cr[1]][1],
		points[child.cr[0]][child.cr[1]][2]);

	child.ru.set(points[child.cr[0] + child.nextGap][child.cr[1]][0],
		points[child.cr[0] + child.nextGap][child.cr[1]][1],
		points[child.cr[0] + child.nextGap][child.cr[1]][2]);

	child.rd.set(points[child.cr[0] + child.nextGap][child.cr[1] + child.nextGap][0],
		points[child.cr[0] + child.nextGap][child.cr[1] + child.nextGap][1],
		points[child.cr[0] + child.nextGap][child.cr[1] + child.nextGap][2]);

	child.ld.set(points[child.cr[0]][child.cr[1] + child.nextGap][0],
		points[child.cr[0]][child.cr[1] + child.nextGap][1],
		points[child.cr[0]][child.cr[1] + child.nextGap][2]);
}

void insertVertexToPlaneTree(double points[RES + 1][RES + 1][3], DividedPlane *planeArr, DividedPlane &plane) {

	if (plane.nextGap / 2 != 1) {

		insert(points, planeArr[plane.child1], plane, plane.child1, 0, 0);
		insert(points, planeArr[plane.child2], plane, plane.child2, 0, plane.nextGap / 2);
		insert(points, planeArr[plane.child3], plane, plane.child3, plane.nextGap / 2, plane.nextGap / 2);
		insert(points, planeArr[plane.child4], plane, plane.child4, plane.nextGap / 2, 0);

		insertVertexToPlaneTree(points, planeArr, planeArr[plane.child1]);
		insertVertexToPlaneTree(points, planeArr, planeArr[plane.child2]);
		insertVertexToPlaneTree(points, planeArr, planeArr[plane.child3]);
		insertVertexToPlaneTree(points, planeArr, planeArr[plane.child4]);
	}
	else {

		insert(points, planeArr[plane.child1], plane, plane.child1, 0, 0);
		insert(points, planeArr[plane.child2], plane, plane.child2, 0, plane.nextGap / 2);
		insert(points, planeArr[plane.child3], plane, plane.child3, plane.nextGap / 2, plane.nextGap / 2);
		insert(points, planeArr[plane.child4], plane, plane.child4, plane.nextGap / 2, 0);

	}
}

void makingTree(double points[RES + 1][RES + 1][3], DividedPlane *planeArr) {
	int heightCount = 4;
	int	nextStart = heightCount / 4 + 1;
	int height = 1;
	int heightNextGap = pow(2, 10 - height);
	int planeInd = 0;
	int rowStart, columnStart;
	double calEPS;

	for (int i = 0; i < nextStart; i++) {
		columnStart = i * heightNextGap;
		for (int j = 0; j < nextStart; j++) {
			rowStart = j * heightNextGap;
			planeArr[planeInd].child1 = (planeInd + 1) * 4;
			planeArr[planeInd].child2 = (planeInd + 1) * 4 + 1;
			planeArr[planeInd].child3 = (planeInd + 1) * 4 + 2;
			planeArr[planeInd].child4 = (planeInd + 1) * 4 + 3;

			planeArr[planeInd].lu.set(points[columnStart][rowStart][0],
				points[columnStart][rowStart][1],
				points[columnStart][rowStart][2]);

			planeArr[planeInd].ru.set(points[columnStart][rowStart + heightNextGap][0],
				points[columnStart][rowStart + heightNextGap][1],
				points[columnStart][rowStart + heightNextGap][2]);

			planeArr[planeInd].rd.set(points[columnStart + heightNextGap][rowStart + heightNextGap][0],
				points[columnStart + heightNextGap][rowStart + heightNextGap][1],
				points[columnStart + heightNextGap][rowStart + heightNextGap][2]);

			planeArr[planeInd].ld.set(points[columnStart + heightNextGap][rowStart][0],
				points[columnStart + heightNextGap][rowStart][1],
				points[columnStart + heightNextGap][rowStart][2]);

			planeArr[planeInd].cr[0] = columnStart;
			planeArr[planeInd].cr[1] = rowStart;
			planeArr[planeInd].nextGap = heightNextGap;


			planeArr[planeInd].ind = planeInd;

			planeInd++;
		}
	}

	insertVertexToPlaneTree(points, planeArr, planeArr[0]);
	insertVertexToPlaneTree(points, planeArr, planeArr[1]);
	insertVertexToPlaneTree(points, planeArr, planeArr[2]);
	insertVertexToPlaneTree(points, planeArr, planeArr[3]);
}

void drawLine(std::vector<std::vector<Vector3d>> &pointsMesh, DividedPlane plane) {

	int length = plane.nextGap;

	glColor3f(0, 0, 0);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= length; i++)
	{
		glVertex3f(pointsMesh[plane.cr[0]][plane.cr[1] + i].x, pointsMesh[plane.cr[0]][plane.cr[1] + i].y, pointsMesh[plane.cr[0]][plane.cr[1] + i].z);
	}
	glEnd();
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= length; i++)
	{
		glVertex3f(pointsMesh[plane.cr[0] + i][plane.cr[1] + length].x, pointsMesh[plane.cr[0] + i][plane.cr[1] + length].y, pointsMesh[plane.cr[0] + i][plane.cr[1] + length].z);
	}
	glEnd();
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= length; i++)
	{
		glVertex3f(pointsMesh[plane.cr[0] + length][plane.cr[1] + length - i].x, pointsMesh[plane.cr[0] + length][plane.cr[1] + length - i].y, pointsMesh[plane.cr[0] + length][plane.cr[1] + length - i].z);
	}
	glEnd();
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= length; i++)
	{
		glVertex3f(pointsMesh[plane.cr[0] + length - i][plane.cr[1]].x, pointsMesh[plane.cr[0] + length - i][plane.cr[1]].y, pointsMesh[plane.cr[0] + length - i][plane.cr[1]].z);
	}
	glEnd();
}
void isRealSmall(std::vector<std::vector<Vector3d>> &pointsMesh, DividedPlane *planeArr, DividedPlane plane, double myEPS) {
	if (plane.eps > myEPS) {
		drawLine(pointsMesh, plane);

		if (plane.child1 != -1) {
			isRealSmall(pointsMesh, planeArr, planeArr[plane.child1], myEPS);
			isRealSmall(pointsMesh, planeArr, planeArr[plane.child2], myEPS);
			isRealSmall(pointsMesh, planeArr, planeArr[plane.child3], myEPS);
			isRealSmall(pointsMesh, planeArr, planeArr[plane.child4], myEPS);
		}
	}
}
void checkEPS(std::vector<std::vector<Vector3d>> &pointsMesh, DividedPlane *planeArr, double myEPS) {
	drawLine(pointsMesh, planeArr[0]);
	drawLine(pointsMesh, planeArr[1]);
	drawLine(pointsMesh, planeArr[2]);
	drawLine(pointsMesh, planeArr[3]);
	isRealSmall(pointsMesh, planeArr, planeArr[0], myEPS);
	isRealSmall(pointsMesh, planeArr, planeArr[1], myEPS);
	isRealSmall(pointsMesh, planeArr, planeArr[2], myEPS);
	isRealSmall(pointsMesh, planeArr, planeArr[3], myEPS);
}

void pointMove(REAL pointArr[4][3], DividedPlane &planeArr) {

	pointArr[0][0] = planeArr.lu.x;
	pointArr[0][1] = planeArr.lu.y;
	pointArr[0][2] = planeArr.lu.z;

	pointArr[1][0] = planeArr.ru.x;
	pointArr[1][1] = planeArr.ru.y;
	pointArr[1][2] = planeArr.ru.z;

	pointArr[2][0] = planeArr.rd.x;
	pointArr[2][1] = planeArr.rd.y;
	pointArr[2][2] = planeArr.rd.z;

	pointArr[3][0] = planeArr.ld.x;
	pointArr[3][1] = planeArr.ld.y;
	pointArr[3][2] = planeArr.ld.z;

}

int tetrahedron[20] = { 4, 8, 12, 16, 1, 2, 3, -1, 0, 2, 3, -1, 0, 1, 3, -1, 0, 1, 2, -1 };

REAL tr1[3][4] = { { 1, 0, 0, 0 },{ 0, 1, 0, 0 },{ 0, 0, 1, 0 } };
REAL tr2[3][4] = { { 1, 0, 0, 0 },{ 0, 1, 0, 0 },{ 0, 0, 1, 0 } };

REAL wpt1[3] = { 0, 0, 0 }, wpt2[3] = { 0, 0, 0 };

REAL twpt1[3] = { 0, 0, 0 }, ttwpt1[3] = { 0, 0, 0 };
REAL twpt2[3] = { 0, 0, 0 }, ttwpt2[3] = { 0, 0, 0 };
REAL twpt3[3] = { 0, 0, 0 }, ttwpt3[3] = { 0, 0, 0 };
REAL twpt4[3] = { 0, 0, 0 }, ttwpt4[3] = { 0, 0, 0 };

REAL pointArr[4][3] = { 0, };
REAL fixedPointArr[4][3] = { 0, };
REAL temp1[4][3] = { 0, };
REAL temp2[4][3] = { 0, };
REAL temp3[4][3] = { 0, };
REAL temp4[4][3] = { 0, };

Object_structure obj1, obj2;
Object_structure t1, t2, t3, t4;

int count = 0;

void isRealCollide(DividedPlane *planeArr, DividedPlane *fixedPlaneArr, DividedPlane &plane, DividedPlane &fixedPlane) {
	
	obj1.numpoints = 4;
	obj2.numpoints = 4;
	//t1.numpoints = 4;
	//t2.numpoints = 4;
	//t3.numpoints = 4;
	//t4.numpoints = 4;

	obj1.rings = tetrahedron;
	obj2.rings = tetrahedron;
	//t1.rings = tetrahedron;
	//t2.rings = tetrahedron;
	//t3.rings = tetrahedron;
	//t4.rings = tetrahedron;

	pointMove(pointArr, plane);
	pointMove(fixedPointArr, fixedPlane);
	
	/*printf("x = %f, y = %f, z = %f\n", fixedPlane.lu.x, fixedPlane.lu.y, fixedPlane.lu.z);
	printf("x = %f, y = %f, z = %f\n", fixedPlane.ld.x, fixedPlane.ld.y, fixedPlane.ld.z);
	printf("x = %f, y = %f, z = %f\n", fixedPlane.rd.x, fixedPlane.rd.y, fixedPlane.rd.z);
	printf("x = %f, y = %f, z = %f\n", fixedPlane.ru.x, fixedPlane.ru.y, fixedPlane.ru.z);
	printf("\n\n");*/

	obj1.vertices = pointArr;
	obj2.vertices = fixedPointArr;

	REAL dist = gjk_distance(&obj1, tr1, &obj2, tr2, wpt1, wpt2, NULL, 0);

	if (floor(dist) == 0) {
		
		/*glColor3f(0, 0, 0);
		glBegin(GL_POINTS);
		glVertex3f(pointArr[0][0], pointArr[0][1], pointArr[0][2]);
		glColor3f(0, 0, 0);
		glVertex3f(pointArr[1][0], pointArr[1][1], pointArr[1][2]);
		glColor3f(0, 0, 0);
		glVertex3f(pointArr[2][0], pointArr[2][1], pointArr[2][2]);
		glColor3f(0, 0, 0);
		glVertex3f(pointArr[3][0], pointArr[3][1], pointArr[3][2]);
		glEnd();

		printf("planechild1 = %d, planechild1 = %d, planechild1 = %d, planechild1 = %d\n", plane.child1, plane.child2, plane.child3, plane.child4);
		printf("child1lux = %f, child1luy = %f, child1luz = %f\n", planeArr[plane.child1].lu.x, planeArr[plane.child1].lu.y, planeArr[plane.child1].lu.z);
		printf("child1rux = %f, child1ruy = %f, child1ruz = %f\n", planeArr[plane.child1].ru.x, planeArr[plane.child1].ru.y, planeArr[plane.child1].ru.z);
		printf("child1rdx = %f, child1rdy = %f, child1rdz = %f\n", planeArr[plane.child1].rd.x, planeArr[plane.child1].rd.y, planeArr[plane.child1].rd.z);
		printf("child1ldx = %f, child1ldy = %f, child1ldz = %f\n", planeArr[plane.child1].ld.x, planeArr[plane.child1].ld.y, planeArr[plane.child1].ld.z);

		glColor3f(255, 125, 125);
		glBegin(GL_POINTS);
		glVertex3f(wpt1[0], wpt1[1], wpt1[2]);
		printf("x = %f, y = %f, z = %f\n", wpt1[0], wpt1[1], wpt1[2]);
		glEnd();*/
		/*pointMove(temp1, fixedPlaneArr[fixedPlane.child1]);
		pointMove(temp2, fixedPlaneArr[fixedPlane.child2]);
		pointMove(temp3, fixedPlaneArr[fixedPlane.child3]);
		pointMove(temp4, fixedPlaneArr[fixedPlane.child4]);

		t1.vertices = temp1;
		t2.vertices = temp2;
		t3.vertices = temp3;
		t4.vertices = temp4;

		REAL tdist1 = gjk_distance(&obj1, tr1, &t1, tr2, twpt1, ttwpt1, NULL, 0);
		REAL tdist2 = gjk_distance(&obj1, tr1, &t2, tr2, twpt2, ttwpt2, NULL, 0);
		REAL tdist3 = gjk_distance(&obj1, tr1, &t3, tr2, twpt3, ttwpt3, NULL, 0);
		REAL tdist4 = gjk_distance(&obj1, tr1, &t4, tr2, twpt4, ttwpt4, NULL, 0);*/

		if (plane.nextGap == 1) {

			Vector3d planeVec, fixedPlaneVec, point;
			REAL tempX = (plane.lu.x + plane.ld.x + plane.ru.x + plane.rd.x) / 4;
			REAL tempY = (plane.lu.y + plane.ld.y + plane.ru.y + plane.rd.y) / 4;
			REAL tempZ = (plane.lu.z + plane.ld.z + plane.ru.z + plane.rd.z) / 4;

			planeVec.set(tempX, tempY, tempZ);

			tempX = (fixedPlane.lu.x + fixedPlane.ld.x + fixedPlane.ru.x + fixedPlane.rd.x) / 4;
			tempY = (fixedPlane.lu.y + fixedPlane.ld.y + fixedPlane.ru.y + fixedPlane.rd.y) / 4;
			tempZ = (fixedPlane.lu.z + fixedPlane.ld.z + fixedPlane.ru.z + fixedPlane.rd.z) / 4;

			fixedPlaneVec.set(tempX, tempY, tempZ);

			point.x = (planeVec.x + fixedPlaneVec.x) / 2;
			point.y = (planeVec.y + fixedPlaneVec.y) / 2;
			point.z = (planeVec.z + fixedPlaneVec.z) / 2;

			glColor3f(255, 125, 255);
			glBegin(GL_POINTS);
			glPointSize(1);
			glVertex3f(point.x, point.y, point.z);
			glEnd();
		}
		else {
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child1], fixedPlaneArr[fixedPlane.child1]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child1], fixedPlaneArr[fixedPlane.child2]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child1], fixedPlaneArr[fixedPlane.child3]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child1], fixedPlaneArr[fixedPlane.child4]);

			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child2], fixedPlaneArr[fixedPlane.child1]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child2], fixedPlaneArr[fixedPlane.child2]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child2], fixedPlaneArr[fixedPlane.child3]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child2], fixedPlaneArr[fixedPlane.child4]);

			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child3], fixedPlaneArr[fixedPlane.child1]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child3], fixedPlaneArr[fixedPlane.child2]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child3], fixedPlaneArr[fixedPlane.child3]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child3], fixedPlaneArr[fixedPlane.child4]);

			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child4], fixedPlaneArr[fixedPlane.child1]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child4], fixedPlaneArr[fixedPlane.child2]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child4], fixedPlaneArr[fixedPlane.child3]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child4], fixedPlaneArr[fixedPlane.child4]);
		}
	}
	
	/*if (count > 1 && floor(dist) != 0) {
		glColor3f(255, 0, 0);
		glBegin(GL_POINTS);
		glVertex3f(wpt1[0], wpt1[1], wpt1[2]);
		glEnd();

		glColor3f(0, 255, 0);
		glBegin(GL_POINTS);
		glVertex3f(wpt2[0], wpt2[1], wpt2[2]);
		glEnd();

		printf("nextGap = %d\n", plane.nextGap);
	}*/

	/*if (plane.nextGap == 128) {
		glColor3f(255, 0, 0);
		glBegin(GL_POINTS);
		glVertex3f(plane.lu.x, plane.lu.y, plane.lu.z);
		glVertex3f(plane.ru.x, plane.ru.y, plane.ru.z);
		glVertex3f(plane.rd.x, plane.rd.y, plane.rd.z);
		glVertex3f(plane.ld.x, plane.ld.y, plane.ld.z);
		glEnd();
		glColor3f(0, 255, 0);
		glBegin(GL_POINTS);
		glVertex3f(fixedPlane.lu.x, fixedPlane.lu.y, fixedPlane.lu.z);
		glVertex3f(fixedPlane.ru.x, fixedPlane.ru.y, fixedPlane.ru.z);
		glVertex3f(fixedPlane.rd.x, fixedPlane.rd.y, fixedPlane.rd.z);
		glVertex3f(fixedPlane.ld.x, fixedPlane.ld.y, fixedPlane.ld.z);
		glEnd();

		printf("dist = %f\n", dist);
		glColor3f(255, 0, 0);
		glBegin(GL_POINTS);
		glVertex3f(wpt1[0], wpt1[1], wpt1[2]);
		glEnd();

		glColor3f(0, 255, 0);
		glBegin(GL_POINTS);
		glVertex3f(wpt2[0], wpt2[1], wpt2[2]);

		glEnd();
	}*/

	/*if (floor(dist) != 0) {
		printf("dist = %e\n", floor(dist));
		printf("planeInd = %d, fixedPlaneInd = %d\n", plane.ind, fixedPlane.ind);
		glColor3f(255, 0, 0);
		glBegin(GL_POINTS);
		glVertex3f(plane.lu.x, plane.lu.y, plane.lu.z);
		glVertex3f(plane.ru.x, plane.ru.y, plane.ru.z);
		glVertex3f(plane.rd.x, plane.rd.y, plane.rd.z);
		glVertex3f(plane.ld.x, plane.ld.y, plane.ld.z);
		glEnd();
		printf("child1 = %d, child2 = %d, child3 = %d, child4 = %d\n", plane.child1, plane.child2, plane.child3, plane.child4);
	}*/

	/*printf("dist = %f\n", dist);

	if (floor(dist)==0) {
		if (plane.nextGap == 1) {
			glColor3f(125, 125, 255);
			glBegin(GL_POINTS);
			glVertex3f(wpt1[0], wpt1[1], wpt1[2]);
			glEnd();
		}
		else {
			count++;
			
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child1]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child2]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child3]);
			isRealCollide(planeArr, fixedPlaneArr, planeArr[plane.child4]);
		}
	}*/

}

void collisionDetection(DividedPlane *planeArr, DividedPlane *fixedPlaneArr) {

	count = 0;

	isRealCollide(planeArr, fixedPlaneArr, planeArr[0], fixedPlaneArr[0]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[0], fixedPlaneArr[1]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[0], fixedPlaneArr[2]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[0], fixedPlaneArr[3]);

	isRealCollide(planeArr, fixedPlaneArr, planeArr[1], fixedPlaneArr[0]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[1], fixedPlaneArr[1]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[1], fixedPlaneArr[2]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[1], fixedPlaneArr[3]);
	
	isRealCollide(planeArr, fixedPlaneArr, planeArr[2], fixedPlaneArr[0]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[2], fixedPlaneArr[1]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[2], fixedPlaneArr[2]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[2], fixedPlaneArr[3]);
	
	isRealCollide(planeArr, fixedPlaneArr, planeArr[3], fixedPlaneArr[0]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[3], fixedPlaneArr[1]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[3], fixedPlaneArr[2]);
	isRealCollide(planeArr, fixedPlaneArr, planeArr[3], fixedPlaneArr[3]);
}

//glColor3f(0, 0, 0);
//glBegin(GL_POINTS);
//glVertex3f(fixedPlaneArr[2].lu.x, fixedPlaneArr[2].lu.y, fixedPlaneArr[2].lu.z);
//glVertex3f(fixedPlaneArr[2].ld.x, fixedPlaneArr[2].ld.y, fixedPlaneArr[2].ld.z);
//glVertex3f(fixedPlaneArr[2].rd.x, fixedPlaneArr[2].rd.y, fixedPlaneArr[2].rd.z);
//glVertex3f(fixedPlaneArr[2].ru.x, fixedPlaneArr[2].ru.y, fixedPlaneArr[2].ru.z);
//glEnd();

//drawLine(planeArr[0].lu, planeArr[0].ld, planeArr[0].ru, planeArr[0].rd);
//drawLine(planeArr[1].lu, planeArr[1].ld, planeArr[1].ru, planeArr[1].rd);
//drawLine(planeArr[2].lu, planeArr[2].ld, planeArr[2].ru, planeArr[2].rd);
//drawLine(planeArr[3].lu, planeArr[3].ld, planeArr[3].ru, planeArr[3].rd);